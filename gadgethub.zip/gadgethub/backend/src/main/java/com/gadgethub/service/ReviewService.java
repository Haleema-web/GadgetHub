package com.gadgethub.service;

import com.gadgethub.dto.ReviewRequest;
import com.gadgethub.exception.ResourceNotFoundException;
import com.gadgethub.model.Gadget;
import com.gadgethub.model.Review;
import com.gadgethub.model.User;
import com.gadgethub.repository.GadgetRepository;
import com.gadgethub.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final GadgetRepository gadgetRepository;

    public List<Review> getReviewsForGadget(Long gadgetId) {
        return reviewRepository.findByGadget_GadgetIdOrderByCreatedAtDesc(gadgetId);
    }

    public Review addReview(User user, Long gadgetId, ReviewRequest req) {
        Gadget gadget = gadgetRepository.findById(gadgetId)
                .orElseThrow(() -> new ResourceNotFoundException("Gadget not found"));

        Review review = new Review();
        review.setGadget(gadget);
        review.setUser(user);
        review.setRating(req.getRating());
        review.setComment(req.getComment());
        Review saved = reviewRepository.save(review);

        recalculateRating(gadget);
        return saved;
    }

    private void recalculateRating(Gadget gadget) {
        List<Review> reviews = reviewRepository.findByGadget_GadgetIdOrderByCreatedAtDesc(gadget.getGadgetId());
        if (reviews.isEmpty()) return;

        double avg = reviews.stream().mapToInt(Review::getRating).average().orElse(0.0);
        gadget.setRating(BigDecimal.valueOf(avg).setScale(1, RoundingMode.HALF_UP));
        gadget.setReviewCount(reviews.size());
        gadgetRepository.save(gadget);
    }
}
