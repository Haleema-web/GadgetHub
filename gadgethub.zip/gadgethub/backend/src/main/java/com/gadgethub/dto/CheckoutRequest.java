package com.gadgethub.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckoutRequest {
    @NotBlank(message = "Delivery name is required")
    private String deliveryName;

    @NotBlank(message = "Delivery phone is required")
    private String deliveryPhone;

    @NotBlank(message = "Delivery address is required")
    private String deliveryAddress;

    private String deliveryCity;
    private String deliveryPincode;

    @NotBlank(message = "Payment method is required")
    private String paymentMethod; // "COD" or "DEMO_CARD"
}
