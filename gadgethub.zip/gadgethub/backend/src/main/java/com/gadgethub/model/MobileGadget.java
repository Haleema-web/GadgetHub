package com.gadgethub.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * MobileGadget extends Gadget — demonstrates INHERITANCE.
 * Overrides displayDetails(), getGadgetType() and getSpecifications()
 * — demonstrates METHOD OVERRIDING.
 */
@Entity
@Table(name = "mobile_gadgets")
@DiscriminatorValue("MOBILE")
@Getter
@Setter
@NoArgsConstructor
public class MobileGadget extends Gadget {

    @Column(name = "camera_mp")
    private Integer cameraMP;

    @Column(name = "battery_capacity")
    private Integer batteryCapacity; // mAh

    @Column(name = "screen_size")
    private Double screenSize; // inches

    @Column(name = "operating_system", length = 40)
    private String operatingSystem;

    @Column(name = "storage_gb")
    private Integer storage; // GB

    @Override
    public String getGadgetType() {
        return "MobileGadget";
    }

    @Override
    public String displayDetails() {
        return String.format(
            "[Mobile] %s %s — ₹%s | Camera: %dMP | Battery: %dmAh | Display: %.1f\" | OS: %s | Storage: %dGB",
            getBrand(), getName(), getPrice(), cameraMP, batteryCapacity, screenSize, operatingSystem, storage
        );
    }

    @Override
    public Map<String, Object> getSpecifications() {
        Map<String, Object> specs = new LinkedHashMap<>();
        specs.put("Camera", cameraMP + " MP");
        specs.put("Battery", batteryCapacity + " mAh");
        specs.put("Display", screenSize + "\"");
        specs.put("OS", operatingSystem);
        specs.put("Storage", storage + " GB");
        return specs;
    }
}
