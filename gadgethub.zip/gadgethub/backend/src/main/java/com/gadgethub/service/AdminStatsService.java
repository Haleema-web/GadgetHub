package com.gadgethub.service;

import com.gadgethub.model.Gadget;
import com.gadgethub.model.LaptopGadget;
import com.gadgethub.model.MobileGadget;
import com.gadgethub.model.Order;
import com.gadgethub.repository.GadgetRepository;
import com.gadgethub.repository.OrderRepository;
import com.gadgethub.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AdminStatsService {

    private final GadgetRepository gadgetRepository;
    private final UserRepository userRepository;
    private final OrderRepository orderRepository;

    public Map<String, Object> getDashboardStats() {
        List<Gadget> gadgets = gadgetRepository.findAll();
        List<Order> orders = orderRepository.findAll();

        long mobileCount = gadgets.stream().filter(g -> g instanceof MobileGadget).count();
        long laptopCount = gadgets.stream().filter(g -> g instanceof LaptopGadget).count();

        BigDecimal totalRevenue = orders.stream()
                .filter(o -> o.getStatus() != Order.OrderStatus.CANCELLED)
                .map(Order::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, Long> byCategory = new HashMap<>();
        for (Gadget g : gadgets) {
            byCategory.merge(g.getGadgetType(), 1L, Long::sum);
        }

        Map<String, Long> byStatus = new HashMap<>();
        for (Order o : orders) {
            byStatus.merge(o.getStatus().name(), 1L, Long::sum);
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalProducts", gadgets.size());
        stats.put("totalUsers", userRepository.count());
        stats.put("totalOrders", orders.size());
        stats.put("totalRevenue", totalRevenue);
        stats.put("lowStock", gadgetRepository.findByStockLessThanEqual(5).size());
        stats.put("mobileProducts", mobileCount);
        stats.put("laptopProducts", laptopCount);
        stats.put("productsByCategory", byCategory);
        stats.put("ordersByStatus", byStatus);
        return stats;
    }
}
