package com.gadgethub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point of the GadgetHub Electronic Gadgets Store backend.
 *
 * This application demonstrates core Object-Oriented Programming concepts
 * (Inheritance, Method Overriding, Runtime Polymorphism, Dynamic Binding)
 * through the Gadget class hierarchy located in com.gadgethub.model.
 *
 * See com.gadgethub.service.PolymorphismDemoService for a concrete,
 * runnable demonstration of runtime polymorphism used for the project viva.
 */
@SpringBootApplication
public class GadgetHubApplication {
    public static void main(String[] args) {
        SpringApplication.run(GadgetHubApplication.class, args);
    }
}
