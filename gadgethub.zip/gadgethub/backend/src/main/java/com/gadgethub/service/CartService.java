package com.gadgethub.service;

import com.gadgethub.dto.CartItemRequest;
import com.gadgethub.exception.BadRequestException;
import com.gadgethub.exception.ResourceNotFoundException;
import com.gadgethub.model.Cart;
import com.gadgethub.model.CartItem;
import com.gadgethub.model.Gadget;
import com.gadgethub.model.User;
import com.gadgethub.repository.CartItemRepository;
import com.gadgethub.repository.CartRepository;
import com.gadgethub.repository.GadgetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final GadgetRepository gadgetRepository;

    public Cart getCartForUser(User user) {
        return cartRepository.findByUser_UserId(user.getUserId())
                .orElseGet(() -> {
                    Cart cart = new Cart();
                    cart.setUser(user);
                    return cartRepository.save(cart);
                });
    }

    public Cart addItem(User user, CartItemRequest req) {
        Cart cart = getCartForUser(user);
        Gadget gadget = gadgetRepository.findById(req.getGadgetId())
                .orElseThrow(() -> new ResourceNotFoundException("Gadget not found"));

        if (gadget.getStock() <= 0) {
            throw new BadRequestException("This product is currently out of stock");
        }
        if (req.getQuantity() > gadget.getStock()) {
            throw new BadRequestException("Only " + gadget.getStock() + " units available in stock");
        }

        CartItem existing = cartItemRepository
                .findByCart_CartIdAndGadget_GadgetId(cart.getCartId(), gadget.getGadgetId())
                .orElse(null);

        if (existing != null) {
            int newQty = existing.getQuantity() + req.getQuantity();
            if (newQty > gadget.getStock()) {
                throw new BadRequestException("Only " + gadget.getStock() + " units available in stock");
            }
            existing.setQuantity(newQty);
            cartItemRepository.save(existing);
        } else {
            CartItem item = new CartItem();
            item.setCart(cart);
            item.setGadget(gadget);
            item.setQuantity(req.getQuantity());
            cart.getItems().add(item);
            cartItemRepository.save(item);
        }
        return getCartForUser(user);
    }

    public Cart updateItemQuantity(User user, Long cartItemId, int quantity) {
        if (quantity < 1) {
            throw new BadRequestException("Quantity must be at least 1");
        }
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart item not found"));

        if (!item.getCart().getUser().getUserId().equals(user.getUserId())) {
            throw new BadRequestException("This cart item does not belong to you");
        }
        if (quantity > item.getGadget().getStock()) {
            throw new BadRequestException("Only " + item.getGadget().getStock() + " units available in stock");
        }
        item.setQuantity(quantity);
        cartItemRepository.save(item);
        return getCartForUser(user);
    }

    public Cart removeItem(User user, Long cartItemId) {
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart item not found"));
        if (!item.getCart().getUser().getUserId().equals(user.getUserId())) {
            throw new BadRequestException("This cart item does not belong to you");
        }
        cartItemRepository.delete(item);
        return getCartForUser(user);
    }

    public Cart clearCart(User user) {
        Cart cart = getCartForUser(user);
        cart.getItems().clear();
        return cartRepository.save(cart);
    }
}
