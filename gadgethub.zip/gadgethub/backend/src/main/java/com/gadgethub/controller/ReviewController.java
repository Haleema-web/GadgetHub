package com.gadgethub.controller;

import com.gadgethub.dto.ReviewRequest;
import com.gadgethub.model.Review;
import com.gadgethub.model.User;
import com.gadgethub.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/gadgets/{gadgetId}/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @GetMapping
    public ResponseEntity<List<Review>> getReviews(@PathVariable Long gadgetId) {
        return ResponseEntity.ok(reviewService.getReviewsForGadget(gadgetId));
    }

    @PostMapping
    public ResponseEntity<Review> addReview(@AuthenticationPrincipal User user, @PathVariable Long gadgetId,
                                             @Valid @RequestBody ReviewRequest request) {
        return ResponseEntity.ok(reviewService.addReview(user, gadgetId, request));
    }
}
