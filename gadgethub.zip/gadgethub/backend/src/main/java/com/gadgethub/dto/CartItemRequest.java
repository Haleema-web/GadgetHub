package com.gadgethub.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartItemRequest {
    @NotNull(message = "gadgetId is required")
    private Long gadgetId;

    @Min(value = 1, message = "Quantity must be at least 1")
    private int quantity = 1;
}
