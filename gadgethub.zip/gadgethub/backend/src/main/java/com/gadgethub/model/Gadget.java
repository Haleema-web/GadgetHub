package com.gadgethub.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * ================================================================
 *  OOP CORE — BASE CLASS OF THE GADGET INHERITANCE HIERARCHY
 * ================================================================
 *
 *                         Gadget (this class)
 *                            |
 *      -----------------------------------------------------
 *      |             |                |                    |
 *  MobileGadget  LaptopGadget  SmartwatchGadget      AccessoryGadget
 *
 * Gadget is the abstract superclass. It defines the common state
 * (name, brand, price, stock ...) and the common behaviour contract
 * displayDetails(), which every subclass OVERRIDES with its own
 * category-specific implementation.
 *
 * InheritanceType.JOINED maps this class to the "gadgets" table and
 * each subclass to its own table (mobile_gadgets, laptop_gadgets,
 * smartwatch_gadgets, accessories) joined on the primary key — this
 * mirrors the Java inheritance structure directly in the database.
 */
@Entity
@Table(name = "gadgets")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "gadget_type", discriminatorType = DiscriminatorType.STRING)
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public abstract class Gadget {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "gadget_id")
    private Long gadgetId;

    @Column(nullable = false, length = 150)
    private String name;

    @Column(nullable = false, length = 80)
    private String brand;

    @Column(length = 80)
    private String model;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "original_price", precision = 10, scale = 2)
    private BigDecimal originalPrice;

    @Column(nullable = false)
    private Integer stock = 0;

    @Column(length = 60)
    private String warranty;

    @Column(precision = 2, scale = 1)
    private BigDecimal rating = BigDecimal.ZERO;

    @Column(name = "review_count")
    private Integer reviewCount = 0;

    @Lob
    @Column(length = 2000)
    private String description;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    @Column(name = "is_active", nullable = false)
    private boolean active = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    /**
     * ==========================================================
     * POLYMORPHIC / OVERRIDABLE METHOD
     * ==========================================================
     * Each subclass overrides this method to return details specific
     * to its own category. When called through a Gadget reference,
     * the JVM performs DYNAMIC BINDING (a.k.a. late binding / runtime
     * polymorphism): the actual method executed is determined by the
     * real object type at runtime, not by the declared reference type.
     *
     * See PolymorphismDemoService for a live demonstration.
     */
    public String displayDetails() {
        return String.format(
            "[%s] %s %s — ₹%s (Stock: %d, Rating: %s/5, Warranty: %s)",
            getGadgetType(), brand, name, price, stock, rating, warranty
        );
    }

    /**
     * Each subclass overrides this to identify its own category.
     * Used purely for display / discriminator purposes, distinct
     * from the JPA @DiscriminatorColumn which drives persistence.
     */
    public String getGadgetType() {
        return "Gadget";
    }

    /**
     * Category-specific specification map, overridden by every subclass
     * so the frontend can render only the fields relevant to that category
     * (e.g. Camera/Battery for mobiles, Processor/RAM for laptops).
     */
    public java.util.Map<String, Object> getSpecifications() {
        return new java.util.LinkedHashMap<>();
    }

    public BigDecimal getDiscountPercentage() {
        if (originalPrice == null || originalPrice.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        BigDecimal diff = originalPrice.subtract(price);
        return diff.multiply(BigDecimal.valueOf(100))
                .divide(originalPrice, 0, java.math.RoundingMode.HALF_UP);
    }
}
