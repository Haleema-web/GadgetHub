package com.gadgethub.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * SmartwatchGadget extends Gadget — INHERITANCE + METHOD OVERRIDING.
 */
@Entity
@Table(name = "smartwatch_gadgets")
@DiscriminatorValue("SMARTWATCH")
@Getter
@Setter
@NoArgsConstructor
public class SmartwatchGadget extends Gadget {

    @Column(name = "display_type", length = 40)
    private String displayType;

    @Column(name = "battery_life", length = 40)
    private String batteryLife;

    @Column(name = "water_resistance", length = 40)
    private String waterResistance;

    @Column(name = "compatible_os", length = 60)
    private String compatibleOS;

    @Override
    public String getGadgetType() {
        return "SmartwatchGadget";
    }

    @Override
    public String displayDetails() {
        return String.format(
            "[Smartwatch] %s %s — ₹%s | Display: %s | Battery: %s | Water Resistance: %s | Compatible OS: %s",
            getBrand(), getName(), getPrice(), displayType, batteryLife, waterResistance, compatibleOS
        );
    }

    @Override
    public Map<String, Object> getSpecifications() {
        Map<String, Object> specs = new LinkedHashMap<>();
        specs.put("Display", displayType);
        specs.put("Battery", batteryLife);
        specs.put("Water Resistance", waterResistance);
        specs.put("Compatible OS", compatibleOS);
        return specs;
    }
}
