package com.gadgethub.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "categories")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_id")
    private Long categoryId;

    @Column(nullable = false, unique = true, length = 60)
    private String name;

    @Column(length = 200)
    private String icon;

    @Column(length = 300)
    private String description;

    public Category(String name, String icon, String description) {
        this.name = name;
        this.icon = icon;
        this.description = description;
    }
}
