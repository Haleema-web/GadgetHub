package com.gadgethub.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LaptopGadget extends Gadget — INHERITANCE.
 * Overrides displayDetails() etc. — METHOD OVERRIDING.
 */
@Entity
@Table(name = "laptop_gadgets")
@DiscriminatorValue("LAPTOP")
@Getter
@Setter
@NoArgsConstructor
public class LaptopGadget extends Gadget {

    @Column(length = 80)
    private String processor;

    @Column(name = "ram_gb")
    private Integer ram; // GB

    @Column(name = "storage_gb")
    private Integer storage; // GB

    @Column(name = "graphics_card", length = 80)
    private String graphicsCard;

    @Column(name = "operating_system", length = 40)
    private String operatingSystem;

    @Column(name = "screen_size")
    private Double screenSize;

    @Override
    public String getGadgetType() {
        return "LaptopGadget";
    }

    @Override
    public String displayDetails() {
        return String.format(
            "[Laptop] %s %s — ₹%s | CPU: %s | RAM: %dGB | Storage: %dGB | GPU: %s | OS: %s | Display: %.1f\"",
            getBrand(), getName(), getPrice(), processor, ram, storage, graphicsCard, operatingSystem, screenSize
        );
    }

    @Override
    public Map<String, Object> getSpecifications() {
        Map<String, Object> specs = new LinkedHashMap<>();
        specs.put("Processor", processor);
        specs.put("RAM", ram + " GB");
        specs.put("Storage", storage + " GB SSD");
        specs.put("Graphics", graphicsCard);
        specs.put("OS", operatingSystem);
        specs.put("Display", screenSize + "\"");
        return specs;
    }
}
