package com.gadgethub.controller;

import com.gadgethub.dto.CartItemRequest;
import com.gadgethub.model.Cart;
import com.gadgethub.model.User;
import com.gadgethub.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    @GetMapping
    public ResponseEntity<Cart> getCart(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(cartService.getCartForUser(user));
    }

    @PostMapping
    public ResponseEntity<Cart> addItem(@AuthenticationPrincipal User user, @Valid @RequestBody CartItemRequest request) {
        return ResponseEntity.ok(cartService.addItem(user, request));
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Cart> updateItem(@AuthenticationPrincipal User user, @PathVariable Long itemId,
                                            @RequestBody java.util.Map<String, Integer> body) {
        int quantity = body.getOrDefault("quantity", 1);
        return ResponseEntity.ok(cartService.updateItemQuantity(user, itemId, quantity));
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Cart> removeItem(@AuthenticationPrincipal User user, @PathVariable Long itemId) {
        return ResponseEntity.ok(cartService.removeItem(user, itemId));
    }

    @DeleteMapping
    public ResponseEntity<Cart> clearCart(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(cartService.clearCart(user));
    }
}
