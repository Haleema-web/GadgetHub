package com.gadgethub.model;

public enum Role {
    USER,
    ADMIN
}
