package com.gadgethub.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * AccessoryGadget extends Gadget — INHERITANCE + METHOD OVERRIDING.
 * Covers headphones, chargers, mice, keyboards, bags, etc.
 */
@Entity
@Table(name = "accessories")
@DiscriminatorValue("ACCESSORY")
@Getter
@Setter
@NoArgsConstructor
public class AccessoryGadget extends Gadget {

    @Column(name = "accessory_type", length = 60)
    private String accessoryType; // e.g. Headphones, Charger, Mouse, Keyboard, Bag

    @Column(length = 150)
    private String compatibility; // e.g. "Universal", "USB-C devices"

    @Override
    public String getGadgetType() {
        return "AccessoryGadget";
    }

    @Override
    public String displayDetails() {
        return String.format(
            "[Accessory] %s %s — ₹%s | Type: %s | Compatibility: %s",
            getBrand(), getName(), getPrice(), accessoryType, compatibility
        );
    }

    @Override
    public Map<String, Object> getSpecifications() {
        Map<String, Object> specs = new LinkedHashMap<>();
        specs.put("Type", accessoryType);
        specs.put("Compatibility", compatibility);
        return specs;
    }
}
