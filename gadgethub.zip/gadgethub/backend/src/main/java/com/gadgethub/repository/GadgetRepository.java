package com.gadgethub.repository;

import com.gadgethub.model.Gadget;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface GadgetRepository extends JpaRepository<Gadget, Long> {

    List<Gadget> findByCategory_Name(String categoryName);

    List<Gadget> findByBrandIgnoreCase(String brand);

    @Query("SELECT g FROM Gadget g WHERE g.active = true AND (" +
           "LOWER(g.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(g.brand) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(g.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Gadget> search(@Param("keyword") String keyword);

    List<Gadget> findByActiveTrueOrderByCreatedAtDesc();

    List<Gadget> findTop10ByActiveTrueOrderByRatingDesc();

    List<Gadget> findByStockLessThanEqual(int threshold);
}
