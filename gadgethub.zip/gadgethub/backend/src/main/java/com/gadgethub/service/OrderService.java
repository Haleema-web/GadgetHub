package com.gadgethub.service;

import com.gadgethub.dto.CheckoutRequest;
import com.gadgethub.exception.BadRequestException;
import com.gadgethub.exception.ResourceNotFoundException;
import com.gadgethub.model.*;
import com.gadgethub.repository.GadgetRepository;
import com.gadgethub.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final GadgetRepository gadgetRepository;
    private final CartService cartService;

    @Transactional
    public Order checkout(User user, CheckoutRequest req) {
        Cart cart = cartService.getCartForUser(user);
        if (cart.getItems().isEmpty()) {
            throw new BadRequestException("Your cart is empty");
        }

        Order.PaymentMethod method;
        try {
            method = Order.PaymentMethod.valueOf(req.getPaymentMethod().toUpperCase());
        } catch (Exception e) {
            throw new BadRequestException("Invalid payment method. Use COD or DEMO_CARD");
        }

        Order order = new Order();
        order.setOrderNumber("GH-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        order.setUser(user);
        order.setDeliveryName(req.getDeliveryName());
        order.setDeliveryPhone(req.getDeliveryPhone());
        order.setDeliveryAddress(req.getDeliveryAddress());
        order.setDeliveryCity(req.getDeliveryCity());
        order.setDeliveryPincode(req.getDeliveryPincode());
        order.setPaymentMethod(method);
        order.setStatus(Order.OrderStatus.PLACED);

        BigDecimal subtotal = BigDecimal.ZERO;

        for (CartItem cartItem : cart.getItems()) {
            Gadget gadget = gadgetRepository.findById(cartItem.getGadget().getGadgetId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product no longer available"));

            if (cartItem.getQuantity() > gadget.getStock()) {
                throw new BadRequestException(
                        "\"" + gadget.getName() + "\" only has " + gadget.getStock() + " units left in stock");
            }

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setGadget(gadget);
            orderItem.setGadgetName(gadget.getName());
            orderItem.setUnitPrice(gadget.getPrice());
            orderItem.setQuantity(cartItem.getQuantity());
            order.getItems().add(orderItem);

            subtotal = subtotal.add(gadget.getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity())));

            // decrement stock
            gadget.setStock(gadget.getStock() - cartItem.getQuantity());
            gadgetRepository.save(gadget);
        }

        BigDecimal deliveryFee = subtotal.compareTo(new BigDecimal("999")) >= 0
                ? BigDecimal.ZERO : new BigDecimal("49");

        order.setSubtotal(subtotal);
        order.setDeliveryFee(deliveryFee);
        order.setTotal(subtotal.add(deliveryFee));

        Order saved = orderRepository.save(order);

        // empty the cart after a successful order
        cartService.clearCart(user);

        return saved;
    }

    public List<Order> getOrdersForUser(User user) {
        return orderRepository.findByUser_UserIdOrderByCreatedAtDesc(user.getUserId());
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAllByOrderByCreatedAtDesc();
    }

    public Order getById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }

    public Order updateStatus(Long id, String status) {
        Order order = getById(id);
        try {
            order.setStatus(Order.OrderStatus.valueOf(status.toUpperCase()));
        } catch (Exception e) {
            throw new BadRequestException("Invalid order status");
        }
        return orderRepository.save(order);
    }
}
