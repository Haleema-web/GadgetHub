package com.gadgethub.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Generic incoming payload used by the admin "Add / Edit Gadget" form.
 * gadgetType selects which Gadget subclass gets instantiated
 * (MOBILE / LAPTOP / SMARTWATCH / ACCESSORY), and only the fields
 * relevant to that subclass need be supplied — this is what powers
 * the dynamic add/edit form on the frontend.
 */
@Getter
@Setter
public class GadgetRequest {

    @NotBlank(message = "gadgetType is required (MOBILE, LAPTOP, SMARTWATCH, ACCESSORY)")
    private String gadgetType;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Brand is required")
    private String brand;

    private String model;

    @NotNull(message = "Price is required")
    @Positive(message = "Price must be positive")
    private BigDecimal price;

    private BigDecimal originalPrice;

    @NotNull(message = "Stock is required")
    @PositiveOrZero(message = "Stock cannot be negative")
    private Integer stock;

    private String warranty;
    private String description;
    private String imageUrl;
    private Long categoryId;

    // Mobile-specific
    private Integer cameraMP;
    private Integer batteryCapacity;
    private Double screenSize;
    private String operatingSystem;
    private Integer storage;

    // Laptop-specific
    private String processor;
    private Integer ram;
    private String graphicsCard;

    // Smartwatch-specific
    private String displayType;
    private String batteryLife;
    private String waterResistance;
    private String compatibleOS;

    // Accessory-specific
    private String accessoryType;
    private String compatibility;
}
