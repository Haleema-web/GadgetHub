package com.gadgethub.service;

import com.gadgethub.model.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * ================================================================
 *  LIVE DEMONSTRATION OF RUNTIME POLYMORPHISM AND DYNAMIC BINDING
 * ================================================================
 *
 * This class exists purely to make the OOP concepts required by the
 * problem statement explicit and easy to show during the viva.
 *
 * Notice: the variable `gadget` is always declared with the type
 * Gadget (the superclass reference). At runtime it is reassigned to
 * different subclass objects (MobileGadget, LaptopGadget, ...), and
 * calling gadget.displayDetails() executes a DIFFERENT method body
 * each time — the correct overridden version for the actual object.
 *
 * This is Runtime Polymorphism achieved through Dynamic (Late) Binding:
 * the JVM decides which displayDetails() to run by looking at the
 * object's real class at runtime, not the reference's declared type,
 * which is resolved at compile time.
 */
@Service
public class PolymorphismDemoService {

    public List<String> runDemo() {
        List<String> output = new ArrayList<>();

        // Declared type is the superclass Gadget in every single line below.
        Gadget gadget;

        MobileGadget mobile = new MobileGadget();
        mobile.setBrand("Samsung");
        mobile.setName("Galaxy Demo Phone");
        mobile.setPrice(new BigDecimal("29999"));
        mobile.setStock(10);
        mobile.setCameraMP(50);
        mobile.setBatteryCapacity(5000);
        mobile.setScreenSize(6.7);
        mobile.setOperatingSystem("Android 14");
        mobile.setStorage(128);

        gadget = mobile; // Gadget reference now points to a MobileGadget object
        output.add("gadget = new MobileGadget(...);");
        output.add("gadget.displayDetails() -> " + gadget.displayDetails());

        LaptopGadget laptop = new LaptopGadget();
        laptop.setBrand("Dell");
        laptop.setName("Inspiron Demo Laptop");
        laptop.setPrice(new BigDecimal("64999"));
        laptop.setStock(5);
        laptop.setProcessor("Intel Core i7");
        laptop.setRam(16);
        laptop.setStorage(512);
        laptop.setGraphicsCard("NVIDIA RTX 3050");
        laptop.setOperatingSystem("Windows 11");
        laptop.setScreenSize(15.6);

        gadget = laptop; // SAME reference variable now points to a LaptopGadget object
        output.add("gadget = new LaptopGadget(...);");
        output.add("gadget.displayDetails() -> " + gadget.displayDetails());

        SmartwatchGadget watch = new SmartwatchGadget();
        watch.setBrand("Noise");
        watch.setName("ColorFit Demo Watch");
        watch.setPrice(new BigDecimal("2999"));
        watch.setStock(20);
        watch.setDisplayType("AMOLED");
        watch.setBatteryLife("7 days");
        watch.setWaterResistance("5 ATM");
        watch.setCompatibleOS("Android & iOS");

        gadget = watch;
        output.add("gadget = new SmartwatchGadget(...);");
        output.add("gadget.displayDetails() -> " + gadget.displayDetails());

        AccessoryGadget accessory = new AccessoryGadget();
        accessory.setBrand("boAt");
        accessory.setName("Rockerz Demo Headphones");
        accessory.setPrice(new BigDecimal("1499"));
        accessory.setStock(30);
        accessory.setAccessoryType("Headphones");
        accessory.setCompatibility("Universal Bluetooth");

        gadget = accessory;
        output.add("gadget = new AccessoryGadget(...);");
        output.add("gadget.displayDetails() -> " + gadget.displayDetails());

        output.add("");
        output.add("Observation: the same statement `gadget.displayDetails()` " +
                "produced four different results because the JVM resolved the " +
                "method call using the OBJECT's actual runtime type, not the " +
                "compile-time reference type (Gadget). This is Dynamic Binding.");

        return output;
    }
}
