package com.gadgethub.config;

import com.gadgethub.model.*;
import com.gadgethub.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Populates the database with categories, demo accounts and 30+ realistic
 * sample products (10+ mobiles, 10+ laptops, 5+ smartwatches, 5+ accessories)
 * so the application works immediately after setup. Runs once — it skips
 * seeding if gadgets already exist.
 */
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final GadgetRepository gadgetRepository;
    private final UserRepository userRepository;
    private final CartRepository cartRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.seed.enabled:true}")
    private boolean seedEnabled;

    @Override
    public void run(String... args) {
        if (!seedEnabled || gadgetRepository.count() > 0) {
            return;
        }

        System.out.println(">>> Seeding GadgetHub sample data...");

        Map<String, Category> categories = seedCategories();
        seedUsers();
        seedMobiles(categories.get("Mobiles"));
        seedLaptops(categories.get("Laptops"));
        seedSmartwatches(categories.get("Smartwatches"));
        seedAccessories(categories.get("Accessories"));

        System.out.println(">>> Seeding complete: " + gadgetRepository.count() + " products created.");
    }

    private Map<String, Category> seedCategories() {
        List<Category> cats = List.of(
            new Category("Mobiles", "📱", "Smartphones from every leading brand"),
            new Category("Laptops", "💻", "Laptops for work, study and gaming"),
            new Category("Smartwatches", "⌚", "Fitness and lifestyle smartwatches"),
            new Category("Accessories", "🎧", "Headphones, chargers, mice, keyboards and more"),
            new Category("Gaming", "🎮", "Gaming laptops and gaming accessories"),
            new Category("Audio", "🔊", "Headphones and speakers")
        );
        categoryRepository.saveAll(cats);
        return categoryRepository.findAll().stream()
                .collect(java.util.stream.Collectors.toMap(Category::getName, c -> c));
    }

    private void seedUsers() {
        User admin = new User();
        admin.setFullName("GadgetHub Admin");
        admin.setEmail("admin@gadgethub.com");
        admin.setPassword(passwordEncoder.encode("Admin@123"));
        admin.setRole(Role.ADMIN);
        admin.setPhone("9999999999");
        admin = userRepository.save(admin);
        Cart adminCart = new Cart();
        adminCart.setUser(admin);
        cartRepository.save(adminCart);

        User demo = new User();
        demo.setFullName("Demo User");
        demo.setEmail("user@gadgethub.com");
        demo.setPassword(passwordEncoder.encode("User@123"));
        demo.setRole(Role.USER);
        demo.setPhone("9888888888");
        demo = userRepository.save(demo);
        Cart demoCart = new Cart();
        demoCart.setUser(demo);
        cartRepository.save(demoCart);
    }

    private MobileGadget mobile(String brand, String name, String model, String price, String original,
                                 int stock, int cameraMP, int battery, double screen, String os, int storage,
                                 double rating, int reviews, Category cat) {
        MobileGadget m = new MobileGadget();
        m.setBrand(brand); m.setName(name); m.setModel(model);
        m.setPrice(new BigDecimal(price)); m.setOriginalPrice(new BigDecimal(original));
        m.setStock(stock); m.setWarranty("1 Year Manufacturer Warranty");
        m.setRating(BigDecimal.valueOf(rating)); m.setReviewCount(reviews);
        m.setDescription(brand + " " + name + " — a reliable " + storage + "GB smartphone with a " + cameraMP + "MP camera system.");
        m.setImageUrl("https://placehold.co/500x500/2563EB/FFFFFF?text=" + name.replace(" ", "+"));
        m.setCameraMP(cameraMP); m.setBatteryCapacity(battery); m.setScreenSize(screen);
        m.setOperatingSystem(os); m.setStorage(storage); m.setCategory(cat);
        return m;
    }

    private LaptopGadget laptop(String brand, String name, String model, String price, String original,
                                 int stock, String cpu, int ram, int storage, String gpu, String os, double screen,
                                 double rating, int reviews, Category cat) {
        LaptopGadget l = new LaptopGadget();
        l.setBrand(brand); l.setName(name); l.setModel(model);
        l.setPrice(new BigDecimal(price)); l.setOriginalPrice(new BigDecimal(original));
        l.setStock(stock); l.setWarranty("1 Year Manufacturer Warranty");
        l.setRating(BigDecimal.valueOf(rating)); l.setReviewCount(reviews);
        l.setDescription(brand + " " + name + " powered by " + cpu + " with " + ram + "GB RAM for smooth multitasking.");
        l.setImageUrl("https://placehold.co/500x500/111827/FFFFFF?text=" + name.replace(" ", "+"));
        l.setProcessor(cpu); l.setRam(ram); l.setStorage(storage); l.setGraphicsCard(gpu);
        l.setOperatingSystem(os); l.setScreenSize(screen); l.setCategory(cat);
        return l;
    }

    private SmartwatchGadget watch(String brand, String name, String price, String original, int stock,
                                    String display, String battery, String water, String compat,
                                    double rating, int reviews, Category cat) {
        SmartwatchGadget w = new SmartwatchGadget();
        w.setBrand(brand); w.setName(name);
        w.setPrice(new BigDecimal(price)); w.setOriginalPrice(new BigDecimal(original));
        w.setStock(stock); w.setWarranty("1 Year Manufacturer Warranty");
        w.setRating(BigDecimal.valueOf(rating)); w.setReviewCount(reviews);
        w.setDescription(brand + " " + name + " with a " + display + " display and " + battery + " battery life.");
        w.setImageUrl("https://placehold.co/500x500/6366F1/FFFFFF?text=" + name.replace(" ", "+"));
        w.setDisplayType(display); w.setBatteryLife(battery); w.setWaterResistance(water);
        w.setCompatibleOS(compat); w.setCategory(cat);
        return w;
    }

    private AccessoryGadget accessory(String brand, String name, String price, String original, int stock,
                                       String type, String compat, double rating, int reviews, Category cat) {
        AccessoryGadget a = new AccessoryGadget();
        a.setBrand(brand); a.setName(name);
        a.setPrice(new BigDecimal(price)); a.setOriginalPrice(new BigDecimal(original));
        a.setStock(stock); a.setWarranty("6 Months Warranty");
        a.setRating(BigDecimal.valueOf(rating)); a.setReviewCount(reviews);
        a.setDescription(brand + " " + name + " — " + type + " compatible with " + compat + ".");
        a.setImageUrl("https://placehold.co/500x500/F5F7FA/111827?text=" + name.replace(" ", "+"));
        a.setAccessoryType(type); a.setCompatibility(compat); a.setCategory(cat);
        return a;
    }

    private void seedMobiles(Category cat) {
        gadgetRepository.saveAll(List.of(
            mobile("Samsung", "Galaxy S24 Ultra", "SM-S928", "124999", "139999", 15, 200, 5000, 6.8, "Android 14", 256, 4.7, 812, cat),
            mobile("Samsung", "Galaxy M34 5G", "SM-M346", "17999", "21999", 40, 50, 6000, 6.5, "Android 13", 128, 4.3, 2130, cat),
            mobile("Apple", "iPhone 15", "A3092", "69999", "79900", 20, 48, 3349, 6.1, "iOS 17", 128, 4.8, 3400, cat),
            mobile("Apple", "iPhone 14", "A2882", "59999", "69900", 18, 12, 3279, 6.1, "iOS 16", 128, 4.7, 5210, cat),
            mobile("OnePlus", "OnePlus 12", "CPH2573", "64999", "69999", 25, 50, 5400, 6.82, "OxygenOS 14", 256, 4.6, 1540, cat),
            mobile("OnePlus", "OnePlus Nord CE 4", "CPH2609", "24999", "27999", 35, 50, 5500, 6.7, "OxygenOS 14", 128, 4.4, 980, cat),
            mobile("Google", "Pixel 8", "GC3VE", "75999", "79999", 12, 50, 4575, 6.2, "Android 14", 128, 4.6, 640, cat),
            mobile("Google", "Pixel 7a", "GHL1X", "43999", "49999", 22, 64, 4385, 6.1, "Android 13", 128, 4.5, 1120, cat),
            mobile("Xiaomi", "Redmi Note 13 Pro", "23113RA", "23999", "27999", 50, 200, 5100, 6.67, "MIUI 14", 256, 4.4, 3450, cat),
            mobile("Xiaomi", "Xiaomi 14", "23127P", "69999", "74999", 14, 50, 4610, 6.36, "HyperOS", 512, 4.5, 410, cat),
            mobile("Vivo", "Vivo V29", "V2244", "31999", "35999", 30, 50, 4600, 6.78, "Funtouch OS 13", 256, 4.3, 890, cat),
            mobile("Realme", "Realme 12 Pro+", "RMX3840", "27999", "31999", 28, 50, 5000, 6.7, "Realme UI 5.0", 256, 4.2, 670, cat)
        ));
    }

    private void seedLaptops(Category cat) {
        gadgetRepository.saveAll(List.of(
            laptop("Dell", "Inspiron 15 3520", "3520", "48999", "56999", 16, "Intel Core i5-1235U", 16, 512, "Intel Iris Xe", "Windows 11", 15.6, 4.3, 980, cat),
            laptop("Dell", "XPS 13 Plus", "9320", "134999", "149999", 6, "Intel Core i7-1360P", 16, 1024, "Intel Iris Xe", "Windows 11", 13.4, 4.7, 210, cat),
            laptop("HP", "Pavilion 15", "15-eg2", "54999", "62999", 14, "Intel Core i5-1335U", 16, 512, "Intel Iris Xe", "Windows 11", 15.6, 4.4, 1230, cat),
            laptop("HP", "Victus Gaming 15", "fb2", "64999", "74999", 10, "AMD Ryzen 5 7535HS", 16, 512, "NVIDIA RTX 3050", "Windows 11", 15.6, 4.5, 640, cat),
            laptop("Lenovo", "IdeaPad Slim 5", "14ABR8", "52999", "59999", 18, "AMD Ryzen 5 7530U", 16, 512, "AMD Radeon Graphics", "Windows 11", 14.0, 4.4, 730, cat),
            laptop("Lenovo", "Legion 5 Pro", "16IRX8", "134999", "154999", 5, "Intel Core i7-13700HX", 16, 1024, "NVIDIA RTX 4060", "Windows 11", 16.0, 4.8, 320, cat),
            laptop("ASUS", "TUF Gaming F15", "FX507", "74999", "84999", 9, "Intel Core i5-12500H", 16, 512, "NVIDIA RTX 3050", "Windows 11", 15.6, 4.5, 890, cat),
            laptop("ASUS", "Vivobook 15", "X1504", "39999", "45999", 25, "Intel Core i3-1215U", 8, 512, "Intel UHD Graphics", "Windows 11", 15.6, 4.1, 1540, cat),
            laptop("Apple", "MacBook Air M2", "MLXW3", "104999", "119900", 11, "Apple M2", 8, 256, "Apple 8-core GPU", "macOS Sonoma", 13.6, 4.9, 1980, cat),
            laptop("Apple", "MacBook Pro 14 M3", "MTL73", "169999", "189900", 6, "Apple M3", 16, 512, "Apple 10-core GPU", "macOS Sonoma", 14.2, 4.9, 540, cat),
            laptop("Acer", "Aspire 7", "A715-76", "56999", "64999", 15, "Intel Core i5-12450H", 16, 512, "NVIDIA RTX 2050", "Windows 11", 15.6, 4.3, 610, cat),
            laptop("MSI", "Katana 15", "B13V", "84999", "97999", 7, "Intel Core i7-13620H", 16, 512, "NVIDIA RTX 4050", "Windows 11", 15.6, 4.6, 260, cat)
        ));
    }

    private void seedSmartwatches(Category cat) {
        gadgetRepository.saveAll(List.of(
            watch("Samsung", "Galaxy Watch 6", "27999", "32999", 20, "AMOLED", "40 hours", "5 ATM", "Android & Wear OS", 4.6, 780, cat),
            watch("Apple", "Apple Watch Series 9", "41900", "45900", 14, "Retina LTPO OLED", "18 hours", "WR50", "iOS only", 4.8, 2340, cat),
            watch("Noise", "ColorFit Pro 4", "2499", "3999", 60, "AMOLED", "7 days", "IP68", "Android & iOS", 4.2, 5600, cat),
            watch("boAt", "Wave Style", "1499", "2999", 55, "IPS LCD", "7 days", "IP68", "Android & iOS", 4.1, 8900, cat),
            watch("Fire-Boltt", "Phoenix Pro", "1799", "3499", 48, "AMOLED", "7 days", "IP67", "Android & iOS", 4.0, 4200, cat),
            watch("Amazfit", "GTS 4 Mini", "6999", "8999", 22, "AMOLED", "9 days", "5 ATM", "Android & iOS", 4.4, 1230, cat)
        ));
    }

    private void seedAccessories(Category cat) {
        gadgetRepository.saveAll(List.of(
            accessory("Sony", "WH-CH720N Headphones", "8999", "11990", 25, "Over-Ear Headphones", "Universal Bluetooth", 4.6, 1240, cat),
            accessory("JBL", "Tune 760NC Headphones", "5999", "7999", 30, "Over-Ear Headphones", "Universal Bluetooth", 4.5, 2100, cat),
            accessory("boAt", "Rockerz 450 Headphones", "1499", "2990", 80, "On-Ear Headphones", "Universal Bluetooth", 4.2, 12500, cat),
            accessory("Logitech", "MX Master 3S Mouse", "8495", "9995", 20, "Wireless Mouse", "Windows, macOS, Linux", 4.8, 640, cat),
            accessory("Logitech", "M331 Silent Mouse", "1295", "1795", 60, "Wireless Mouse", "Windows, macOS, Linux", 4.5, 3200, cat),
            accessory("Dell", "KM3322W Keyboard & Mouse", "2299", "2999", 35, "Wireless Keyboard & Mouse Combo", "Windows, Chrome OS", 4.4, 890, cat),
            accessory("Anker", "PowerCore 20000 Charger", "2499", "3499", 45, "Power Bank / Charger", "USB-C devices", 4.6, 1980, cat)
        ));
    }
}
