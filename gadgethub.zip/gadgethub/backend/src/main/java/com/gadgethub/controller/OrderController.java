package com.gadgethub.controller;

import com.gadgethub.dto.CheckoutRequest;
import com.gadgethub.model.Order;
import com.gadgethub.model.User;
import com.gadgethub.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> checkout(@AuthenticationPrincipal User user, @Valid @RequestBody CheckoutRequest request) {
        return ResponseEntity.ok(orderService.checkout(user, request));
    }

    @GetMapping
    public ResponseEntity<List<Order>> myOrders(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(orderService.getOrdersForUser(user));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrder(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getById(id));
    }
}
