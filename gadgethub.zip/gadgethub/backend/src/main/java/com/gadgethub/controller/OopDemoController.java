package com.gadgethub.controller;

import com.gadgethub.service.PolymorphismDemoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * GET /api/oop-demo/polymorphism runs PolymorphismDemoService.runDemo()
 * server-side (real Java execution, not a frontend simulation) and
 * returns the step-by-step trace. Used by the "OOP Concepts" page
 * so the demonstration is genuine, live backend behaviour.
 */
@RestController
@RequestMapping("/api/oop-demo")
@RequiredArgsConstructor
public class OopDemoController {

    private final PolymorphismDemoService demoService;

    @GetMapping("/polymorphism")
    public ResponseEntity<List<String>> polymorphismDemo() {
        return ResponseEntity.ok(demoService.runDemo());
    }
}
