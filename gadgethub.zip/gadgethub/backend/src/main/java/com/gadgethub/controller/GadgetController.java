package com.gadgethub.controller;

import com.gadgethub.dto.GadgetRequest;
import com.gadgethub.model.Gadget;
import com.gadgethub.service.GadgetService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/gadgets")
@RequiredArgsConstructor
public class GadgetController {

    private final GadgetService gadgetService;

    @GetMapping
    public ResponseEntity<List<Gadget>> getAll(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String brand,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) Double minRating,
            @RequestParam(required = false) Boolean inStockOnly,
            @RequestParam(required = false, defaultValue = "relevance") String sortBy
    ) {
        List<Gadget> base = gadgetService.getAll();
        List<Gadget> result = gadgetService.filterAndSort(base, category, brand, minPrice, maxPrice, minRating, inStockOnly, sortBy);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Gadget> getById(@PathVariable Long id) {
        return ResponseEntity.ok(gadgetService.getById(id));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Gadget>> search(@RequestParam String keyword) {
        return ResponseEntity.ok(gadgetService.search(keyword));
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<Gadget>> getByCategory(@PathVariable String category) {
        List<Gadget> all = gadgetService.getAll();
        List<Gadget> filtered = gadgetService.filterAndSort(all, category, null, null, null, null, null, "relevance");
        return ResponseEntity.ok(filtered);
    }

    @GetMapping("/bestsellers")
    public ResponseEntity<List<Gadget>> getBestsellers() {
        return ResponseEntity.ok(gadgetService.getBestsellers());
    }

    @GetMapping("/{id}/related")
    public ResponseEntity<List<Gadget>> getRelated(@PathVariable Long id) {
        Gadget gadget = gadgetService.getById(id);
        String type = gadget.getGadgetType();
        List<Gadget> related = gadgetService.getAll().stream()
                .filter(g -> g.getGadgetType().equals(type) && !g.getGadgetId().equals(id))
                .limit(6)
                .toList();
        return ResponseEntity.ok(related);
    }

    // ---- Admin-only mutations (enforced in SecurityConfig) ----

    @PostMapping
    public ResponseEntity<Gadget> create(@Valid @RequestBody GadgetRequest request) {
        return ResponseEntity.ok(gadgetService.createFromRequest(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Gadget> update(@PathVariable Long id, @Valid @RequestBody GadgetRequest request) {
        return ResponseEntity.ok(gadgetService.updateFromRequest(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {
        gadgetService.delete(id);
        return ResponseEntity.ok(Map.of("message", "Gadget deleted successfully"));
    }
}
