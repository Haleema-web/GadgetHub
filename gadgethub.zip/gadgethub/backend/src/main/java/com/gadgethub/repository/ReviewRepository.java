package com.gadgethub.repository;

import com.gadgethub.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByGadget_GadgetIdOrderByCreatedAtDesc(Long gadgetId);
}
