package com.gadgethub.service;

import com.gadgethub.dto.GadgetRequest;
import com.gadgethub.exception.BadRequestException;
import com.gadgethub.exception.ResourceNotFoundException;
import com.gadgethub.model.*;
import com.gadgethub.repository.CategoryRepository;
import com.gadgethub.repository.GadgetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * GadgetService owns all CRUD, search, filter and sort logic for the
 * Gadget hierarchy, and is also the FACTORY that turns an admin form
 * submission (GadgetRequest, containing a "gadgetType" string) into
 * the correct concrete subclass instance — this is where INHERITANCE
 * and RUNTIME POLYMORPHISM become visible in everyday CRUD operations:
 * the very same save/update/delete code path works for every subclass
 * because they are all handled purely through the Gadget reference type.
 */
@Service
@RequiredArgsConstructor
public class GadgetService {

    private final GadgetRepository gadgetRepository;
    private final CategoryRepository categoryRepository;

    public List<Gadget> getAll() {
        return gadgetRepository.findByActiveTrueOrderByCreatedAtDesc();
    }

    public Gadget getById(Long id) {
        return gadgetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Gadget not found with id: " + id));
    }

    public List<Gadget> search(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return getAll();
        }
        return gadgetRepository.search(keyword.trim());
    }

    public List<Gadget> getByCategory(String categoryName) {
        return gadgetRepository.findByCategory_Name(categoryName);
    }

    public List<Gadget> getBestsellers() {
        return gadgetRepository.findTop10ByActiveTrueOrderByRatingDesc();
    }

    public List<Gadget> getLowStock(int threshold) {
        return gadgetRepository.findByStockLessThanEqual(threshold);
    }

    /**
     * Applies filtering and sorting to a base list of gadgets.
     * Demonstrates that all filtering works uniformly across every
     * Gadget subclass via the common Gadget reference type.
     */
    public List<Gadget> filterAndSort(List<Gadget> base, String category, String brand,
                                       BigDecimal minPrice, BigDecimal maxPrice,
                                       Double minRating, Boolean inStockOnly, String sortBy) {
        List<Gadget> result = base.stream()
            .filter(g -> category == null || category.isBlank() || "all".equalsIgnoreCase(category)
                    || (g.getCategory() != null && g.getCategory().getName().equalsIgnoreCase(category))
                    || g.getGadgetType().toLowerCase().contains(category.toLowerCase()))
            .filter(g -> brand == null || brand.isBlank() || g.getBrand().equalsIgnoreCase(brand))
            .filter(g -> minPrice == null || g.getPrice().compareTo(minPrice) >= 0)
            .filter(g -> maxPrice == null || g.getPrice().compareTo(maxPrice) <= 0)
            .filter(g -> minRating == null || g.getRating().doubleValue() >= minRating)
            .filter(g -> inStockOnly == null || !inStockOnly || g.getStock() > 0)
            .collect(Collectors.toList());

        if (sortBy != null) {
            switch (sortBy) {
                case "price_low" -> result.sort(Comparator.comparing(Gadget::getPrice));
                case "price_high" -> result.sort(Comparator.comparing(Gadget::getPrice).reversed());
                case "rating" -> result.sort(Comparator.comparing(Gadget::getRating).reversed());
                case "newest" -> result.sort(Comparator.comparing(Gadget::getCreatedAt).reversed());
                default -> { /* relevance: leave default order */ }
            }
        }
        return result;
    }

    /**
     * ==========================================================
     * FACTORY METHOD demonstrating polymorphic object creation.
     * ==========================================================
     * Returns a Gadget reference, but the actual object created is
     * one of the four concrete subclasses depending on gadgetType.
     * Every caller of this method works with the Gadget interface
     * only — they never need to know which subclass they received.
     */
    public Gadget createFromRequest(GadgetRequest req) {
        Gadget gadget = buildSubclassInstance(req);
        applyCommonFields(gadget, req);
        return gadgetRepository.save(gadget);
    }

    public Gadget updateFromRequest(Long id, GadgetRequest req) {
        Gadget existing = getById(id);
        applyCommonFields(existing, req);
        applyTypeSpecificFields(existing, req);
        return gadgetRepository.save(existing);
    }

    public void delete(Long id) {
        Gadget gadget = getById(id);
        gadgetRepository.delete(gadget);
    }

    public void deactivate(Long id) {
        Gadget gadget = getById(id);
        gadget.setActive(false);
        gadgetRepository.save(gadget);
    }

    // ---- private helpers ----

    private Gadget buildSubclassInstance(GadgetRequest req) {
        String type = req.getGadgetType() == null ? "" : req.getGadgetType().toUpperCase();
        Gadget gadget = switch (type) {
            case "MOBILE" -> new MobileGadget();
            case "LAPTOP" -> new LaptopGadget();
            case "SMARTWATCH" -> new SmartwatchGadget();
            case "ACCESSORY" -> new AccessoryGadget();
            default -> throw new BadRequestException(
                    "Invalid gadgetType. Must be one of MOBILE, LAPTOP, SMARTWATCH, ACCESSORY");
        };
        applyTypeSpecificFields(gadget, req);
        return gadget;
    }

    private void applyTypeSpecificFields(Gadget gadget, GadgetRequest req) {
        if (gadget instanceof MobileGadget m) {
            m.setCameraMP(req.getCameraMP());
            m.setBatteryCapacity(req.getBatteryCapacity());
            m.setScreenSize(req.getScreenSize());
            m.setOperatingSystem(req.getOperatingSystem());
            m.setStorage(req.getStorage());
        } else if (gadget instanceof LaptopGadget l) {
            l.setProcessor(req.getProcessor());
            l.setRam(req.getRam());
            l.setStorage(req.getStorage());
            l.setGraphicsCard(req.getGraphicsCard());
            l.setOperatingSystem(req.getOperatingSystem());
            l.setScreenSize(req.getScreenSize());
        } else if (gadget instanceof SmartwatchGadget s) {
            s.setDisplayType(req.getDisplayType());
            s.setBatteryLife(req.getBatteryLife());
            s.setWaterResistance(req.getWaterResistance());
            s.setCompatibleOS(req.getCompatibleOS());
        } else if (gadget instanceof AccessoryGadget a) {
            a.setAccessoryType(req.getAccessoryType());
            a.setCompatibility(req.getCompatibility());
        }
    }

    private void applyCommonFields(Gadget gadget, GadgetRequest req) {
        gadget.setName(req.getName());
        gadget.setBrand(req.getBrand());
        gadget.setModel(req.getModel());
        gadget.setPrice(req.getPrice());
        gadget.setOriginalPrice(req.getOriginalPrice());
        gadget.setStock(req.getStock());
        gadget.setWarranty(req.getWarranty());
        gadget.setDescription(req.getDescription());
        gadget.setImageUrl(req.getImageUrl());
        gadget.setActive(true);

        if (req.getCategoryId() != null) {
            Optional<Category> category = categoryRepository.findById(req.getCategoryId());
            category.ifPresent(gadget::setCategory);
        }
    }
}
