-- =====================================================================
-- GadgetHub — Electronic Gadgets Store
-- Reference schema for MySQL database: electronic_gadgets_store
--
-- NOTE: You do NOT need to run this file by hand. Spring Boot /
-- Hibernate creates and updates these exact tables automatically on
-- startup (spring.jpa.hibernate.ddl-auto=update in application.properties).
-- This file is provided purely as documentation of the resulting schema,
-- useful for your viva / report, and as a manual fallback if you prefer
-- to create the schema yourself before first run.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS electronic_gadgets_store;
USE electronic_gadgets_store;

-- ---------- Categories ----------
CREATE TABLE IF NOT EXISTS categories (
    category_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(60)  NOT NULL UNIQUE,
    icon          VARCHAR(200),
    description   VARCHAR(300)
);

-- ---------- Users ----------
CREATE TABLE IF NOT EXISTS users (
    user_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name   VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,          -- BCrypt hash, never plain text
    phone       VARCHAR(20),
    address     VARCHAR(300),
    role        VARCHAR(20)  NOT NULL DEFAULT 'USER',  -- USER | ADMIN
    created_at  DATETIME
);

-- ---------- Gadgets (base class: JPA JOINED inheritance) ----------
CREATE TABLE IF NOT EXISTS gadgets (
    gadget_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    gadget_type     VARCHAR(31) NOT NULL,        -- discriminator: MOBILE / LAPTOP / SMARTWATCH / ACCESSORY
    name            VARCHAR(150) NOT NULL,
    brand           VARCHAR(80)  NOT NULL,
    model           VARCHAR(80),
    price           DECIMAL(10,2) NOT NULL,
    original_price  DECIMAL(10,2),
    stock           INT NOT NULL DEFAULT 0,
    warranty        VARCHAR(60),
    rating          DECIMAL(2,1) DEFAULT 0,
    review_count    INT DEFAULT 0,
    description     TEXT,
    image_url       VARCHAR(500),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    category_id     BIGINT,
    created_at      DATETIME,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- ---------- MobileGadget (extends Gadget) ----------
CREATE TABLE IF NOT EXISTS mobile_gadgets (
    gadget_id           BIGINT PRIMARY KEY,
    camera_mp           INT,
    battery_capacity     INT,
    screen_size          DOUBLE,
    operating_system     VARCHAR(40),
    storage_gb           INT,
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id) ON DELETE CASCADE
);

-- ---------- LaptopGadget (extends Gadget) ----------
CREATE TABLE IF NOT EXISTS laptop_gadgets (
    gadget_id           BIGINT PRIMARY KEY,
    processor            VARCHAR(80),
    ram_gb                INT,
    storage_gb            INT,
    graphics_card         VARCHAR(80),
    operating_system      VARCHAR(40),
    screen_size           DOUBLE,
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id) ON DELETE CASCADE
);

-- ---------- SmartwatchGadget (extends Gadget) ----------
CREATE TABLE IF NOT EXISTS smartwatch_gadgets (
    gadget_id           BIGINT PRIMARY KEY,
    display_type          VARCHAR(40),
    battery_life           VARCHAR(40),
    water_resistance        VARCHAR(40),
    compatible_os            VARCHAR(60),
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id) ON DELETE CASCADE
);

-- ---------- AccessoryGadget (extends Gadget) ----------
CREATE TABLE IF NOT EXISTS accessories (
    gadget_id       BIGINT PRIMARY KEY,
    accessory_type   VARCHAR(60),
    compatibility     VARCHAR(150),
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id) ON DELETE CASCADE
);

-- ---------- Cart / CartItems ----------
CREATE TABLE IF NOT EXISTS cart (
    cart_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id   BIGINT NOT NULL UNIQUE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS cart_items (
    cart_item_id  BIGINT AUTO_INCREMENT PRIMARY KEY,
    cart_id       BIGINT NOT NULL,
    gadget_id     BIGINT NOT NULL,
    quantity      INT NOT NULL DEFAULT 1,
    FOREIGN KEY (cart_id)   REFERENCES cart(cart_id)     ON DELETE CASCADE,
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id) ON DELETE CASCADE
);

-- ---------- Orders / OrderItems ----------
CREATE TABLE IF NOT EXISTS orders (
    order_id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_number      VARCHAR(30) NOT NULL UNIQUE,
    user_id           BIGINT NOT NULL,
    delivery_name     VARCHAR(100) NOT NULL,
    delivery_phone    VARCHAR(20)  NOT NULL,
    delivery_address  TEXT NOT NULL,
    delivery_city     VARCHAR(80),
    delivery_pincode  VARCHAR(12),
    payment_method    VARCHAR(20) NOT NULL,     -- COD | DEMO_CARD
    status            VARCHAR(20) NOT NULL DEFAULT 'PLACED', -- PLACED, CONFIRMED, SHIPPED, DELIVERED, CANCELLED
    subtotal          DECIMAL(10,2) NOT NULL,
    delivery_fee      DECIMAL(10,2) DEFAULT 0,
    total             DECIMAL(10,2) NOT NULL,
    created_at        DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS order_items (
    order_item_id  BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id       BIGINT NOT NULL,
    gadget_id      BIGINT NOT NULL,
    gadget_name    VARCHAR(150) NOT NULL,
    unit_price     DECIMAL(10,2) NOT NULL,
    quantity       INT NOT NULL,
    FOREIGN KEY (order_id)  REFERENCES orders(order_id)   ON DELETE CASCADE,
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id)
);

-- ---------- Reviews ----------
CREATE TABLE IF NOT EXISTS reviews (
    review_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    gadget_id   BIGINT NOT NULL,
    user_id     BIGINT NOT NULL,
    rating      INT NOT NULL,
    comment     TEXT,
    created_at  DATETIME,
    FOREIGN KEY (gadget_id) REFERENCES gadgets(gadget_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)   REFERENCES users(user_id)
);
