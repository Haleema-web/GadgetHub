/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        surface: '#F5F7FA',
        ink: '#111827',
        brand: {
          DEFAULT: '#2563EB',
          dark: '#1D4ED8',
          light: '#DBEAFE'
        },
        accent: '#6366F1',
        deal: '#DC2626',
        success: '#059669'
      },
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        display: ['"Sora"', '"Inter"', 'system-ui', 'sans-serif']
      },
      boxShadow: {
        card: '0 1px 2px rgba(17,24,39,0.06), 0 1px 3px rgba(17,24,39,0.08)',
        cardHover: '0 8px 24px rgba(17,24,39,0.12)'
      }
    },
  },
  plugins: [],
}
