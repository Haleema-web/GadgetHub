import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { cartService } from '../services/cartService';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [cart, setCart] = useState({ items: [] });
  const [loading, setLoading] = useState(false);

  const refreshCart = useCallback(async () => {
    if (!user) {
      setCart({ items: [] });
      return;
    }
    setLoading(true);
    try {
      const data = await cartService.get();
      setCart(data);
    } catch (err) {
      // silently ignore — user might not be authenticated yet
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    refreshCart();
  }, [refreshCart]);

  const addToCart = async (gadgetId, quantity = 1) => {
    if (!user) {
      showToast('Please log in to add items to your cart', 'error');
      return false;
    }
    try {
      const data = await cartService.addItem(gadgetId, quantity);
      setCart(data);
      showToast('Added to cart', 'success');
      return true;
    } catch (err) {
      showToast(err.message, 'error');
      return false;
    }
  };

  const updateQuantity = async (itemId, quantity) => {
    try {
      const data = await cartService.updateItem(itemId, quantity);
      setCart(data);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const removeFromCart = async (itemId) => {
    try {
      const data = await cartService.removeItem(itemId);
      setCart(data);
      showToast('Removed from cart', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const clearCart = async () => {
    const data = await cartService.clear();
    setCart(data);
  };

  const itemCount = (cart.items || []).reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider value={{ cart, itemCount, loading, addToCart, updateQuantity, removeFromCart, clearCart, refreshCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
