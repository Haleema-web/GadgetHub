import { useState, useEffect } from 'react';

function getWishlist() {
  try { return JSON.parse(localStorage.getItem('gadgethub_wishlist') || '[]'); }
  catch { return []; }
}

export default function WishlistButton({ gadgetId, className = '' }) {
  const [active, setActive] = useState(false);

  useEffect(() => {
    setActive(getWishlist().includes(gadgetId));
  }, [gadgetId]);

  const toggle = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const list = getWishlist();
    const next = list.includes(gadgetId) ? list.filter((id) => id !== gadgetId) : [...list, gadgetId];
    localStorage.setItem('gadgethub_wishlist', JSON.stringify(next));
    setActive(!active);
  };

  return (
    <button
      onClick={toggle}
      aria-label="Toggle wishlist"
      className={`w-8 h-8 rounded-full bg-white/90 backdrop-blur flex items-center justify-center shadow-sm hover:scale-105 transition-transform ${className}`}
    >
      <svg className={`w-4 h-4 ${active ? 'text-deal fill-deal' : 'text-gray-500 fill-none'}`} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path d="M12 21s-6.716-4.35-9.428-8.06C.686 10.31 1.06 6.6 4.05 4.86 6.32 3.55 9.02 4.24 12 7.1c2.98-2.86 5.68-3.55 7.95-2.24 2.99 1.74 3.364 5.45 1.478 8.08C18.716 16.65 12 21 12 21z" />
      </svg>
    </button>
  );
}
