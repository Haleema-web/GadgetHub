import { Link } from 'react-router-dom';

export default function CategoryCard({ category, count }) {
  return (
    <Link
      to={`/products?category=${encodeURIComponent(category.name)}`}
      className="card flex flex-col items-center justify-center gap-2 p-5 text-center group"
    >
      <span className="text-3xl group-hover:scale-110 transition-transform">{category.icon}</span>
      <span className="font-semibold text-sm text-ink">{category.name}</span>
      {count !== undefined && <span className="text-xs text-gray-500">{count} products</span>}
      <span className="text-xs font-semibold text-brand mt-1">Explore →</span>
    </Link>
  );
}
