import { Link } from 'react-router-dom';
import Rating from './Rating';
import WishlistButton from './WishlistButton';
import { useCart } from '../context/CartContext';

const TYPE_LABEL = {
  MobileGadget: 'Mobile',
  LaptopGadget: 'Laptop',
  SmartwatchGadget: 'Smartwatch',
  AccessoryGadget: 'Accessory',
};

export default function ProductCard({ gadget }) {
  const { addToCart } = useCart();
  const discount = gadget.discountPercentage || 0;
  const outOfStock = gadget.stock <= 0;

  const handleAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (outOfStock) return;
    addToCart(gadget.gadgetId, 1);
  };

  return (
    <Link to={`/product/${gadget.gadgetId}`} className="card group flex flex-col overflow-hidden">
      <div className="relative bg-gray-50 aspect-square overflow-hidden">
        <span className="absolute top-2 left-2 z-10 text-[11px] font-semibold bg-white/90 text-ink px-2 py-0.5 rounded-full border border-gray-200">
          {TYPE_LABEL[gadget.gadgetType] || 'Gadget'}
        </span>
        <WishlistButton gadgetId={gadget.gadgetId} className="absolute top-2 right-2 z-10" />
        {discount > 0 && (
          <span className="absolute bottom-2 left-2 z-10 text-[11px] font-bold bg-deal text-white px-2 py-0.5 rounded">
            {discount}% OFF
          </span>
        )}
        <img
          src={gadget.imageUrl}
          alt={gadget.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>

      <div className="p-3 flex flex-col gap-1 flex-1">
        <span className="text-xs text-gray-500 font-medium">{gadget.brand}</span>
        <h3 className="text-sm font-semibold text-ink line-clamp-2 leading-snug min-h-[2.5rem]">{gadget.name}</h3>
        <Rating value={gadget.rating || 0} count={gadget.reviewCount || 0} />

        <div className="flex items-baseline gap-2 mt-1">
          <span className="text-lg font-bold text-ink">₹{Number(gadget.price).toLocaleString('en-IN')}</span>
          {gadget.originalPrice && Number(gadget.originalPrice) > Number(gadget.price) && (
            <span className="text-xs text-gray-400 line-through">₹{Number(gadget.originalPrice).toLocaleString('en-IN')}</span>
          )}
        </div>

        <span className={`text-xs font-medium ${outOfStock ? 'text-deal' : 'text-success'}`}>
          {outOfStock ? 'Out of stock' : gadget.stock <= 5 ? `Only ${gadget.stock} left` : 'In stock'}
        </span>
        <span className="text-[11px] text-gray-500">🚚 Fast Delivery</span>

        <button
          onClick={handleAdd}
          disabled={outOfStock}
          className={`mt-2 w-full text-sm font-semibold rounded-lg py-2 transition-colors ${
            outOfStock ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-brand/10 text-brand hover:bg-brand hover:text-white'
          }`}
        >
          {outOfStock ? 'Out of Stock' : 'Add to Cart'}
        </button>
      </div>
    </Link>
  );
}
