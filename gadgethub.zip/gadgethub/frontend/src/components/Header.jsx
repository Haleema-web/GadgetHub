import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { gadgetService } from '../services/gadgetService';

const NAV_LINKS = [
  { label: 'All Categories', to: '/products' },
  { label: 'Mobiles', to: '/products?category=Mobiles' },
  { label: 'Laptops', to: '/products?category=Laptops' },
  { label: 'Smartwatches', to: '/products?category=Smartwatches' },
  { label: 'Accessories', to: '/products?category=Accessories' },
  { label: 'Deals', to: '/products?sort=deals' },
  { label: 'New Arrivals', to: '/products?sort=newest' },
  { label: 'OOP Concepts', to: '/oop-concepts' },
];

export default function Header() {
  const { user, logout, isAdmin } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const searchRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    const timeout = setTimeout(async () => {
      try {
        const results = await gadgetService.search(query.trim());
        setSuggestions(results.slice(0, 6));
        setShowSuggestions(true);
      } catch {
        setSuggestions([]);
      }
    }, 250);
    return () => clearTimeout(timeout);
  }, [query]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    setShowSuggestions(false);
    navigate(`/products?search=${encodeURIComponent(query.trim())}`);
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      {/* Top row */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
        <button className="lg:hidden mr-1" onClick={() => setMobileMenuOpen((v) => !v)} aria-label="Menu">
          <svg className="w-6 h-6 text-ink" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        <Link to="/" className="flex items-center gap-1.5 shrink-0">
          <span className="w-8 h-8 rounded-lg bg-brand flex items-center justify-center text-white font-display font-bold text-sm">G</span>
          <span className="font-display font-extrabold text-lg text-ink hidden sm:inline">GadgetHub</span>
        </Link>

        {/* Search bar - prominent */}
        <div className="flex-1 relative hidden md:block" ref={searchRef}>
          <form onSubmit={handleSearchSubmit} className="flex">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
              placeholder="Search for mobiles, laptops, smartwatches, accessories..."
              className="flex-1 bg-surface border border-gray-300 rounded-l-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand/40"
            />
            <button type="submit" className="bg-brand hover:bg-brand-dark text-white px-4 rounded-r-lg flex items-center justify-center">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-4.35-4.35M17 10.5A6.5 6.5 0 114 10.5a6.5 6.5 0 0113 0z" />
              </svg>
            </button>
          </form>

          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full mt-1 left-0 right-0 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden z-50">
              {suggestions.map((s) => (
                <button
                  key={s.gadgetId}
                  onClick={() => { setShowSuggestions(false); setQuery(''); navigate(`/product/${s.gadgetId}`); }}
                  className="w-full text-left px-4 py-2.5 text-sm hover:bg-surface flex items-center gap-3"
                >
                  <img src={s.imageUrl} alt="" className="w-8 h-8 rounded object-cover bg-gray-100" />
                  <span className="flex-1 truncate">{s.brand} {s.name}</span>
                  <span className="text-xs text-gray-400">₹{Number(s.price).toLocaleString('en-IN')}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center gap-4 ml-auto">
          {user ? (
            <div className="relative group hidden sm:block">
              <button className="flex flex-col text-xs leading-tight text-left">
                <span className="text-gray-500">Hello, {user.fullName.split(' ')[0]}</span>
                <span className="font-semibold text-ink">Account ▾</span>
              </button>
              <div className="absolute right-0 top-full pt-2 hidden group-hover:block z-50">
                <div className="bg-white border border-gray-200 rounded-lg shadow-lg w-44 py-1">
                  <Link to="/orders" className="block px-4 py-2 text-sm hover:bg-surface">My Orders</Link>
                  <Link to="/wishlist" className="block px-4 py-2 text-sm hover:bg-surface">Wishlist</Link>
                  {isAdmin && <Link to="/admin" className="block px-4 py-2 text-sm hover:bg-surface">Admin Dashboard</Link>}
                  <button onClick={logout} className="w-full text-left px-4 py-2 text-sm hover:bg-surface text-deal">Logout</button>
                </div>
              </div>
            </div>
          ) : (
            <Link to="/login" className="hidden sm:flex flex-col text-xs leading-tight">
              <span className="text-gray-500">Hello, sign in</span>
              <span className="font-semibold text-ink">Account ▾</span>
            </Link>
          )}

          <Link to="/orders" className="hidden sm:flex flex-col text-xs leading-tight">
            <span className="text-gray-500">Returns</span>
            <span className="font-semibold text-ink">& Orders</span>
          </Link>

          <Link to="/cart" className="relative flex items-center gap-1">
            <svg className="w-6 h-6 text-ink" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            {itemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-deal text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {itemCount > 9 ? '9+' : itemCount}
              </span>
            )}
            <span className="hidden lg:inline text-sm font-semibold">Cart</span>
          </Link>
        </div>
      </div>

      {/* Mobile search */}
      <div className="md:hidden px-4 pb-3">
        <form onSubmit={handleSearchSubmit} className="flex">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search GadgetHub..."
            className="flex-1 bg-surface border border-gray-300 rounded-l-lg px-3 py-2 text-sm focus:outline-none"
          />
          <button type="submit" className="bg-brand text-white px-3 rounded-r-lg">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-4.35-4.35M17 10.5A6.5 6.5 0 114 10.5a6.5 6.5 0 0113 0z" />
            </svg>
          </button>
        </form>
      </div>

      {/* Second nav row - desktop */}
      <nav className="hidden lg:block bg-ink">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-6 h-10 overflow-x-auto">
          {NAV_LINKS.map((link) => (
            <Link key={link.label} to={link.to} className="text-xs font-medium text-gray-200 hover:text-white whitespace-nowrap">
              {link.label}
            </Link>
          ))}
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-ink px-4 py-3 flex flex-col gap-3">
          {NAV_LINKS.map((link) => (
            <Link key={link.label} to={link.to} onClick={() => setMobileMenuOpen(false)} className="text-sm text-gray-200 hover:text-white">
              {link.label}
            </Link>
          ))}
          <div className="border-t border-gray-700 pt-3 flex flex-col gap-3">
            {user ? (
              <>
                <Link to="/orders" onClick={() => setMobileMenuOpen(false)} className="text-sm text-gray-200">My Orders</Link>
                <Link to="/wishlist" onClick={() => setMobileMenuOpen(false)} className="text-sm text-gray-200">Wishlist</Link>
                {isAdmin && <Link to="/admin" onClick={() => setMobileMenuOpen(false)} className="text-sm text-gray-200">Admin Dashboard</Link>}
                <button onClick={() => { logout(); setMobileMenuOpen(false); }} className="text-sm text-left text-red-300">Logout</button>
              </>
            ) : (
              <Link to="/login" onClick={() => setMobileMenuOpen(false)} className="text-sm text-gray-200">Sign In</Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
