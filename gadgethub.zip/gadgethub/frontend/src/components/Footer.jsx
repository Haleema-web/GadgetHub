import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-ink text-gray-300 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-10 grid grid-cols-2 md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-1.5 mb-3">
            <span className="w-7 h-7 rounded-lg bg-brand flex items-center justify-center text-white font-display font-bold text-xs">G</span>
            <span className="font-display font-extrabold text-white">GadgetHub</span>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Everything tech, all in one place. A BTech IT OOP project demonstrating
            inheritance, polymorphism and dynamic binding through a real e-commerce experience.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-3">Shop</h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li><Link to="/products?category=Mobiles" className="hover:text-white">Mobiles</Link></li>
            <li><Link to="/products?category=Laptops" className="hover:text-white">Laptops</Link></li>
            <li><Link to="/products?category=Smartwatches" className="hover:text-white">Smartwatches</Link></li>
            <li><Link to="/products?category=Accessories" className="hover:text-white">Accessories</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-3">Account</h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li><Link to="/orders" className="hover:text-white">My Orders</Link></li>
            <li><Link to="/wishlist" className="hover:text-white">Wishlist</Link></li>
            <li><Link to="/cart" className="hover:text-white">Cart</Link></li>
            <li><Link to="/login" className="hover:text-white">Sign In</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white mb-3">Project</h4>
          <ul className="space-y-2 text-xs text-gray-400">
            <li><Link to="/oop-concepts" className="hover:text-white">OOP Concepts</Link></li>
            <li><Link to="/about" className="hover:text-white">About GadgetHub</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gray-800 py-4 text-center text-xs text-gray-500">
        GadgetHub — Group No. 03 — BTech Information Technology — Demo project, not a real store.
      </div>
    </footer>
  );
}
