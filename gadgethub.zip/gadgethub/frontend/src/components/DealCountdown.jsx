import { useEffect, useState } from 'react';

function getTargetTime() {
  // Rolls forward to the next midnight for a believable "deal ends" countdown (demo-only, frontend-side)
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  return midnight.getTime();
}

export default function DealCountdown() {
  const [target] = useState(getTargetTime);
  const [remaining, setRemaining] = useState(target - Date.now());

  useEffect(() => {
    const interval = setInterval(() => setRemaining(target - Date.now()), 1000);
    return () => clearInterval(interval);
  }, [target]);

  const clamp = Math.max(remaining, 0);
  const hours = String(Math.floor(clamp / 3_600_000)).padStart(2, '0');
  const minutes = String(Math.floor((clamp % 3_600_000) / 60_000)).padStart(2, '0');
  const seconds = String(Math.floor((clamp % 60_000) / 1000)).padStart(2, '0');

  return (
    <div className="flex items-center gap-1.5 text-xs font-semibold text-deal">
      <span>Deal ends in</span>
      <span className="bg-deal text-white rounded px-1.5 py-0.5 font-mono">{hours}</span>:
      <span className="bg-deal text-white rounded px-1.5 py-0.5 font-mono">{minutes}</span>:
      <span className="bg-deal text-white rounded px-1.5 py-0.5 font-mono">{seconds}</span>
    </div>
  );
}
