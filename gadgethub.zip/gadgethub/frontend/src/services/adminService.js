import api from './api';

export const adminService = {
  getStats: () => api.get('/admin/stats').then((r) => r.data),
  getAllOrders: () => api.get('/admin/orders').then((r) => r.data),
  updateOrderStatus: (id, status) => api.put(`/admin/orders/${id}/status`, { status }).then((r) => r.data),
  getAllUsers: () => api.get('/admin/users').then((r) => r.data),
};
