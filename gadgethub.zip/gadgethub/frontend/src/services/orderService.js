import api from './api';

export const orderService = {
  checkout: (data) => api.post('/orders', data).then((r) => r.data),
  getMyOrders: () => api.get('/orders').then((r) => r.data),
  getById: (id) => api.get(`/orders/${id}`).then((r) => r.data),
};
