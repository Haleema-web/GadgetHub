import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every outgoing request, if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('gadgethub_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Normalize errors into a friendly message and handle expired sessions
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('gadgethub_token');
      localStorage.removeItem('gadgethub_user');
    }
    const message =
      error.response?.data?.message ||
      (error.response?.data?.errors && Object.values(error.response.data.errors)[0]) ||
      'Something went wrong. Please try again.';
    return Promise.reject({ message, status: error.response?.status, raw: error });
  }
);

export default api;
