import api from './api';

export const cartService = {
  get: () => api.get('/cart').then((r) => r.data),
  addItem: (gadgetId, quantity = 1) => api.post('/cart', { gadgetId, quantity }).then((r) => r.data),
  updateItem: (itemId, quantity) => api.put(`/cart/${itemId}`, { quantity }).then((r) => r.data),
  removeItem: (itemId) => api.delete(`/cart/${itemId}`).then((r) => r.data),
  clear: () => api.delete('/cart').then((r) => r.data),
};
