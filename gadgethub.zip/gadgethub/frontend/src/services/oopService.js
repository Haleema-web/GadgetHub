import api from './api';

export const oopService = {
  runPolymorphismDemo: () => api.get('/oop-demo/polymorphism').then((r) => r.data),
};
