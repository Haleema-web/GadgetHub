import api from './api';

export const gadgetService = {
  getAll: (params = {}) => api.get('/gadgets', { params }).then((r) => r.data),
  getById: (id) => api.get(`/gadgets/${id}`).then((r) => r.data),
  search: (keyword) => api.get('/gadgets/search', { params: { keyword } }).then((r) => r.data),
  getByCategory: (category) => api.get(`/gadgets/category/${category}`).then((r) => r.data),
  getBestsellers: () => api.get('/gadgets/bestsellers').then((r) => r.data),
  getRelated: (id) => api.get(`/gadgets/${id}/related`).then((r) => r.data),
  create: (data) => api.post('/gadgets', data).then((r) => r.data),
  update: (id, data) => api.put(`/gadgets/${id}`, data).then((r) => r.data),
  remove: (id) => api.delete(`/gadgets/${id}`).then((r) => r.data),
  getReviews: (id) => api.get(`/gadgets/${id}/reviews`).then((r) => r.data),
  addReview: (id, data) => api.post(`/gadgets/${id}/reviews`, data).then((r) => r.data),
};

export const categoryService = {
  getAll: () => api.get('/categories').then((r) => r.data),
};
