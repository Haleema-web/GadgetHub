import { Link } from 'react-router-dom';

export default function About() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-14 text-center">
      <span className="w-14 h-14 rounded-2xl bg-brand flex items-center justify-center text-white font-display font-bold text-2xl mx-auto mb-4">G</span>
      <h1 className="text-2xl font-bold text-ink mb-1">GadgetHub</h1>
      <p className="text-gray-500 mb-8">Electronic Gadgets Store</p>

      <div className="card p-8 text-left">
        <dl className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
          <div>
            <dt className="text-gray-500 mb-1">Group</dt>
            <dd className="font-semibold text-ink">Group No. 03</dd>
          </div>
          <div>
            <dt className="text-gray-500 mb-1">Built for</dt>
            <dd className="font-semibold text-ink">BTech Information Technology</dd>
          </div>
          <div>
            <dt className="text-gray-500 mb-1">Technology</dt>
            <dd className="font-semibold text-ink">React, Java (Spring Boot), MySQL</dd>
          </div>
          <div>
            <dt className="text-gray-500 mb-1">Purpose</dt>
            <dd className="font-semibold text-ink">Demonstrating OOP through a real e-commerce app</dd>
          </div>
        </dl>

        <div className="border-t border-gray-100 mt-6 pt-6">
          <h2 className="font-semibold text-ink mb-2">Problem Statement</h2>
          <p className="text-sm text-gray-600 leading-relaxed">
            Extension of the system using inheritance hierarchies (MobileGadget, LaptopGadget,
            SmartwatchGadget, AccessoryGadget) to represent different categories of gadgets, and
            implementation of method overriding, runtime polymorphism, and dynamic binding to
            provide category-specific operations in the Electronic Gadgets Store.
          </p>
        </div>

        <Link to="/oop-concepts" className="btn-primary inline-block mt-6">See the OOP Implementation →</Link>
      </div>
    </div>
  );
}
