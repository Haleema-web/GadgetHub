import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { gadgetService } from '../services/gadgetService';
import { useToast } from '../context/ToastContext';

const TYPE_LABEL = {
  MobileGadget: 'Mobile',
  LaptopGadget: 'Laptop',
  SmartwatchGadget: 'Smartwatch',
  AccessoryGadget: 'Accessory',
};

export default function AdminProducts() {
  const { showToast } = useToast();
  const [gadgets, setGadgets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [confirmingId, setConfirmingId] = useState(null);

  const load = () => {
    setLoading(true);
    gadgetService.getAll().then(setGadgets).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleDelete = async (id) => {
    try {
      await gadgetService.remove(id);
      showToast('Product deleted', 'success');
      setGadgets((prev) => prev.filter((g) => g.gadgetId !== id));
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setConfirmingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-ink">Manage Products</h1>
        <Link to="/admin/products/new" className="btn-primary text-sm">+ Add Gadget</Link>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm min-w-[900px]">
          <thead className="bg-surface text-gray-500 text-xs uppercase">
            <tr>
              <th className="px-4 py-3 text-left">ID</th>
              <th className="px-4 py-3 text-left">Image</th>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Category</th>
              <th className="px-4 py-3 text-left">Brand</th>
              <th className="px-4 py-3 text-left">Price</th>
              <th className="px-4 py-3 text-left">Stock</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-gray-400">Loading products...</td></tr>
            ) : gadgets.length === 0 ? (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-gray-400">No products yet.</td></tr>
            ) : (
              gadgets.map((g) => (
                <tr key={g.gadgetId}>
                  <td className="px-4 py-3 text-gray-500">#{g.gadgetId}</td>
                  <td className="px-4 py-3"><img src={g.imageUrl} alt="" className="w-10 h-10 rounded object-cover bg-gray-50" /></td>
                  <td className="px-4 py-3 font-medium text-ink max-w-[220px] truncate">{g.name}</td>
                  <td className="px-4 py-3">{TYPE_LABEL[g.gadgetType] || g.gadgetType}</td>
                  <td className="px-4 py-3">{g.brand}</td>
                  <td className="px-4 py-3">₹{Number(g.price).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3">{g.stock}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-semibold px-2 py-1 rounded-full ${g.stock > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {g.stock > 0 ? 'Active' : 'Out of Stock'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Link to={`/product/${g.gadgetId}`} className="text-xs font-medium text-gray-500 hover:text-ink">View</Link>
                      <Link to={`/admin/products/${g.gadgetId}/edit`} className="text-xs font-medium text-brand">Edit</Link>
                      {confirmingId === g.gadgetId ? (
                        <>
                          <button onClick={() => handleDelete(g.gadgetId)} className="text-xs font-medium text-deal">Confirm</button>
                          <button onClick={() => setConfirmingId(null)} className="text-xs font-medium text-gray-400">Cancel</button>
                        </>
                      ) : (
                        <button onClick={() => setConfirmingId(g.gadgetId)} className="text-xs font-medium text-deal">Delete</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
