import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { gadgetService } from '../services/gadgetService';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Rating from '../components/Rating';
import WishlistButton from '../components/WishlistButton';
import ProductCard from '../components/ProductCard';
import EmptyState from '../components/EmptyState';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const { showToast } = useToast();

  const [gadget, setGadget] = useState(null);
  const [related, setRelated] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    setLoading(true);
    setNotFound(false);
    window.scrollTo(0, 0);

    Promise.all([
      gadgetService.getById(id),
      gadgetService.getRelated(id).catch(() => []),
      gadgetService.getReviews(id).catch(() => []),
    ])
      .then(([g, rel, rev]) => {
        setGadget(g);
        setRelated(rel);
        setReviews(rev);
        localStorage.setItem('gadgethub_last_viewed_type', g.gadgetType);
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return <div className="max-w-7xl mx-auto px-4 py-10 animate-pulse text-gray-400">Loading product...</div>;
  }

  if (notFound || !gadget) {
    return (
      <EmptyState
        icon="📦"
        title="Product not found"
        description="This product may have been removed or the link is incorrect."
        action={<Link to="/products" className="btn-primary">Browse Products</Link>}
      />
    );
  }

  const outOfStock = gadget.stock <= 0;
  const specs = gadget.specifications || {};

  const handleAddToCart = async () => {
    await addToCart(gadget.gadgetId, quantity);
  };

  const handleBuyNow = async () => {
    const ok = await addToCart(gadget.gadgetId, quantity);
    if (ok) navigate('/cart');
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!user) {
      showToast('Please log in to write a review', 'error');
      return;
    }
    setSubmittingReview(true);
    try {
      await gadgetService.addReview(gadget.gadgetId, reviewForm);
      const updated = await gadgetService.getReviews(gadget.gadgetId);
      setReviews(updated);
      const refreshed = await gadgetService.getById(gadget.gadgetId);
      setGadget(refreshed);
      setReviewForm({ rating: 5, comment: '' });
      showToast('Review submitted', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="grid md:grid-cols-2 gap-10">
        {/* Left: images */}
        <div>
          <div className="card aspect-square overflow-hidden mb-3 relative">
            <WishlistButton gadgetId={gadget.gadgetId} className="absolute top-3 right-3 z-10" />
            <img src={gadget.imageUrl} alt={gadget.name} className="w-full h-full object-cover" />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="card aspect-square overflow-hidden opacity-70 hover:opacity-100 cursor-pointer">
                <img src={gadget.imageUrl} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Right: info */}
        <div>
          <span className="text-xs font-semibold text-brand bg-brand/10 rounded-full px-2.5 py-1">{gadget.gadgetType?.replace('Gadget', '')}</span>
          <h1 className="text-2xl font-bold text-ink mt-3 mb-1">{gadget.brand} {gadget.name}</h1>
          {gadget.model && <p className="text-sm text-gray-500 mb-2">Model: {gadget.model}</p>}
          <Rating value={gadget.rating || 0} count={gadget.reviewCount || 0} size="lg" />

          <div className="flex items-baseline gap-3 mt-4">
            <span className="text-3xl font-extrabold text-ink">₹{Number(gadget.price).toLocaleString('en-IN')}</span>
            {gadget.originalPrice && Number(gadget.originalPrice) > Number(gadget.price) && (
              <>
                <span className="text-base text-gray-400 line-through">₹{Number(gadget.originalPrice).toLocaleString('en-IN')}</span>
                <span className="text-sm font-semibold text-deal">{gadget.discountPercentage}% off</span>
              </>
            )}
          </div>

          <p className={`text-sm font-medium mt-2 ${outOfStock ? 'text-deal' : 'text-success'}`}>
            {outOfStock ? 'Out of stock' : gadget.stock <= 5 ? `Only ${gadget.stock} left in stock` : 'In stock'}
          </p>
          <p className="text-xs text-gray-500 mt-1">🚚 Fast Delivery · {gadget.warranty}</p>

          {!outOfStock && (
            <div className="flex items-center gap-3 mt-5">
              <span className="text-sm font-medium text-ink">Qty</span>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <button onClick={() => setQuantity((q) => Math.max(1, q - 1))} className="px-3 py-1.5 text-gray-600">−</button>
                <span className="px-3 text-sm">{quantity}</span>
                <button onClick={() => setQuantity((q) => Math.min(gadget.stock, q + 1))} className="px-3 py-1.5 text-gray-600">+</button>
              </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3 mt-5">
            <button onClick={handleAddToCart} disabled={outOfStock} className="btn-secondary flex-1 disabled:opacity-50">
              {outOfStock ? 'Out of Stock' : 'Add to Cart'}
            </button>
            <button onClick={handleBuyNow} disabled={outOfStock} className="btn-primary flex-1 disabled:opacity-50">
              Buy Now
            </button>
          </div>

          {/* Specifications - dynamic per subclass */}
          <div className="mt-8">
            <h2 className="text-lg font-bold text-ink mb-3">Specifications</h2>
            <div className="card divide-y divide-gray-100">
              {Object.entries(specs).map(([key, value]) => (
                <div key={key} className="flex justify-between px-4 py-2.5 text-sm">
                  <span className="text-gray-500">{key}</span>
                  <span className="font-medium text-ink">{String(value)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="mt-8">
            <h2 className="text-lg font-bold text-ink mb-2">Product Description</h2>
            <p className="text-sm text-gray-600 leading-relaxed">{gadget.description}</p>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-12">
        <h2 className="text-lg font-bold text-ink mb-4">Customer Reviews</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <div className="text-4xl font-bold text-ink">{Number(gadget.rating || 0).toFixed(1)}</div>
            <Rating value={gadget.rating || 0} size="lg" />
            <p className="text-xs text-gray-500 mt-1">{gadget.reviewCount || 0} ratings</p>

            <form onSubmit={handleReviewSubmit} className="mt-6 card p-4">
              <h3 className="text-sm font-semibold text-ink mb-2">Write a review</h3>
              <select
                value={reviewForm.rating}
                onChange={(e) => setReviewForm({ ...reviewForm, rating: Number(e.target.value) })}
                className="w-full border border-gray-300 rounded-lg text-sm px-2 py-1.5 mb-2"
              >
                {[5, 4, 3, 2, 1].map((r) => <option key={r} value={r}>{r} Star{r > 1 ? 's' : ''}</option>)}
              </select>
              <textarea
                value={reviewForm.comment}
                onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                placeholder="Share your experience..."
                rows={3}
                className="w-full border border-gray-300 rounded-lg text-sm px-2 py-1.5 mb-2"
              />
              <button type="submit" disabled={submittingReview} className="btn-primary w-full text-sm disabled:opacity-60">
                {submittingReview ? 'Submitting...' : 'Submit Review'}
              </button>
            </form>
          </div>

          <div className="md:col-span-2">
            {reviews.length === 0 ? (
              <EmptyState icon="✍️" title="No reviews yet" description="Be the first to review this product." />
            ) : (
              <div className="flex flex-col gap-4">
                {reviews.map((r) => (
                  <div key={r.reviewId} className="card p-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold text-ink">{r.user?.fullName || 'GadgetHub User'}</span>
                      <span className="text-xs text-gray-400">{new Date(r.createdAt).toLocaleDateString()}</span>
                    </div>
                    <Rating value={r.rating} />
                    {r.comment && <p className="text-sm text-gray-600 mt-2">{r.comment}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Related products */}
      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="text-lg font-bold text-ink mb-4">Related Products</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {related.map((g) => <ProductCard key={g.gadgetId} gadget={g} />)}
          </div>
        </section>
      )}
    </div>
  );
}
