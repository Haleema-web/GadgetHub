import { useEffect, useState } from 'react';
import { oopService } from '../services/oopService';

const CONCEPTS = [
  {
    title: 'Inheritance',
    desc: 'MobileGadget, LaptopGadget, SmartwatchGadget and AccessoryGadget all extend the common Gadget superclass, reusing its shared fields (name, brand, price, stock...) and behaviour.',
    code: `public class MobileGadget extends Gadget {
    private Integer cameraMP;
    private Integer batteryCapacity;
    // ...inherits gadgetId, name, brand, price, stock, etc.
}`,
  },
  {
    title: 'Method Overriding',
    desc: 'Every subclass redefines displayDetails() (and getSpecifications()) with its own category-specific implementation, replacing the superclass version.',
    code: `@Override
public String displayDetails() {
    return String.format(
      "[Mobile] %s %s | Camera: %dMP | Battery: %dmAh",
      getBrand(), getName(), cameraMP, batteryCapacity
    );
}`,
  },
  {
    title: 'Runtime Polymorphism',
    desc: 'Code written against the Gadget superclass reference works correctly no matter which subclass object it actually holds — the right overridden method executes automatically.',
    code: `Gadget gadget;
gadget = new MobileGadget(...);
gadget.displayDetails();  // runs MobileGadget's version

gadget = new LaptopGadget(...);
gadget.displayDetails();  // runs LaptopGadget's version`,
  },
  {
    title: 'Dynamic Binding',
    desc: "The JVM decides which displayDetails() to execute by inspecting the object's actual runtime type — not the compile-time type of the reference variable (Gadget). This resolution happens at runtime, hence 'dynamic' or 'late' binding.",
    code: `// Declared type: Gadget (compile-time)
// Actual type: whatever was last assigned (runtime)
// JVM looks up the vtable of the ACTUAL object
// -> correct overridden method is invoked`,
  },
];

export default function OopConcepts() {
  const [demoOutput, setDemoOutput] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const runDemo = async () => {
    setLoading(true);
    setError('');
    try {
      const result = await oopService.runPolymorphismDemo();
      setDemoOutput(result);
    } catch (err) {
      setError(err.message || 'Could not reach the backend. Make sure the Spring Boot server is running.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { runDemo(); }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="text-center mb-10">
        <span className="inline-block text-xs font-semibold text-brand bg-brand/10 rounded-full px-3 py-1 mb-3">For the Viva</span>
        <h1 className="text-3xl font-bold text-ink mb-3">How GadgetHub's OOP System Works</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          This page demonstrates the core object-oriented programming concepts implemented
          in the Java Spring Boot backend — not simulated in JavaScript, but real Java code
          you can inspect in <code className="bg-gray-100 px-1 rounded text-xs">com.gadgethub.model</code> and{' '}
          <code className="bg-gray-100 px-1 rounded text-xs">com.gadgethub.service.PolymorphismDemoService</code>.
        </p>
      </div>

      {/* Class hierarchy diagram */}
      <div className="card p-8 mb-10 flex flex-col items-center">
        <div className="bg-ink text-white text-sm font-semibold rounded-lg px-5 py-2.5 mb-4">Gadget (abstract base class)</div>
        <div className="w-px h-6 bg-gray-300" />
        <div className="w-full max-w-2xl h-px bg-gray-300 relative mb-4">
          <div className="absolute left-1/2 -translate-x-1/2 -top-3 text-gray-300">┬</div>
        </div>
        <div className="flex flex-wrap justify-center gap-4">
          {['MobileGadget', 'LaptopGadget', 'SmartwatchGadget', 'AccessoryGadget'].map((c) => (
            <div key={c} className="bg-brand/10 border border-brand/30 text-brand text-sm font-semibold rounded-lg px-4 py-2.5">
              {c}
            </div>
          ))}
        </div>
      </div>

      {/* Concept cards */}
      <div className="grid md:grid-cols-2 gap-5 mb-10">
        {CONCEPTS.map((c) => (
          <div key={c.title} className="card p-5">
            <h3 className="font-bold text-ink mb-2">{c.title}</h3>
            <p className="text-sm text-gray-600 mb-3">{c.desc}</p>
            <pre className="bg-ink text-gray-100 text-xs rounded-lg p-3 overflow-x-auto"><code>{c.code}</code></pre>
          </div>
        ))}
      </div>

      {/* Live demo */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-ink">Live Backend Demonstration</h2>
          <button onClick={runDemo} disabled={loading} className="btn-primary text-sm disabled:opacity-60">
            {loading ? 'Running...' : 'Run Again'}
          </button>
        </div>
        <p className="text-xs text-gray-500 mb-4">
          Calls <code className="bg-gray-100 px-1 rounded">GET /api/oop-demo/polymorphism</code>, which executes real Java code on the server:
          the same <code className="bg-gray-100 px-1 rounded">Gadget gadget</code> reference is reassigned to each subclass in turn and
          <code className="bg-gray-100 px-1 rounded"> gadget.displayDetails()</code> is called each time.
        </p>

        {error && (
          <div className="bg-amber-50 text-amber-700 text-sm rounded-lg px-4 py-3">
            {error} (This is expected if you're viewing the deployed frontend without the backend running.)
          </div>
        )}

        {demoOutput && (
          <pre className="bg-ink text-green-400 text-xs rounded-lg p-4 overflow-x-auto leading-relaxed">
            {demoOutput.map((line, i) => <div key={i}>{line || '\u00A0'}</div>)}
          </pre>
        )}
      </div>
    </div>
  );
}
