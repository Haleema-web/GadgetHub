import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-24 text-center">
      <div className="text-6xl mb-4">🔌</div>
      <h1 className="text-2xl font-bold text-ink mb-2">Page not found</h1>
      <p className="text-gray-500 mb-6">The page you're looking for doesn't exist or was moved.</p>
      <Link to="/" className="btn-primary">Back to Home</Link>
    </div>
  );
}
