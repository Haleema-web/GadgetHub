import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { orderService } from '../services/orderService';
import EmptyState from '../components/EmptyState';

const STATUS_STYLES = {
  PLACED: 'bg-amber-100 text-amber-700',
  CONFIRMED: 'bg-blue-100 text-blue-700',
  SHIPPED: 'bg-indigo-100 text-indigo-700',
  DELIVERED: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    orderService.getMyOrders()
      .then(setOrders)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="max-w-5xl mx-auto px-4 py-10 text-gray-400">Loading orders...</div>;
  if (error) return <div className="max-w-5xl mx-auto px-4 py-10 text-deal">{error}</div>;

  if (orders.length === 0) {
    return (
      <EmptyState
        icon="📦"
        title="No orders yet"
        description="Once you place an order, it will show up here."
        action={<Link to="/products" className="btn-primary">Start Shopping</Link>}
      />
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold text-ink mb-6">My Orders</h1>
      <div className="flex flex-col gap-4">
        {orders.map((order) => (
          <div key={order.orderId} className="card p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div>
                <span className="text-xs text-gray-500">Order ID</span>
                <div className="font-mono font-semibold text-sm text-ink">{order.orderNumber}</div>
              </div>
              <div>
                <span className="text-xs text-gray-500">Placed on</span>
                <div className="text-sm text-ink">{new Date(order.createdAt).toLocaleDateString()}</div>
              </div>
              <div>
                <span className="text-xs text-gray-500">Amount</span>
                <div className="text-sm font-semibold text-ink">₹{Number(order.total).toLocaleString('en-IN')}</div>
              </div>
              <span className={`text-xs font-semibold px-3 py-1 rounded-full ${STATUS_STYLES[order.status] || 'bg-gray-100 text-gray-600'}`}>
                {order.status}
              </span>
            </div>
            <div className="border-t border-gray-100 pt-3 flex flex-col gap-1">
              {order.items.map((item) => (
                <div key={item.orderItemId} className="flex justify-between text-sm text-gray-600">
                  <span>{item.gadgetName} × {item.quantity}</span>
                  <span>₹{(Number(item.unitPrice) * item.quantity).toLocaleString('en-IN')}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
