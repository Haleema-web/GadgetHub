import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import EmptyState from '../components/EmptyState';

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, loading } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const items = cart.items || [];

  if (!user) {
    return (
      <EmptyState
        icon="🔒"
        title="Sign in to view your cart"
        description="Your cart is saved to your account once you're logged in."
        action={<Link to="/login" className="btn-primary">Sign In</Link>}
      />
    );
  }

  if (!loading && items.length === 0) {
    return (
      <EmptyState
        icon="🛒"
        title="Your cart is empty"
        description="Looks like you haven't added anything yet."
        action={<Link to="/products" className="btn-primary">Start Shopping</Link>}
      />
    );
  }

  const subtotal = items.reduce((sum, i) => sum + Number(i.gadget.price) * i.quantity, 0);
  const deliveryFee = subtotal >= 999 || subtotal === 0 ? 0 : 49;
  const total = subtotal + deliveryFee;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold text-ink mb-6">Shopping Cart ({items.length})</h1>

      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1 flex flex-col gap-3">
          {items.map((item) => (
            <div key={item.cartItemId} className="card p-4 flex gap-4">
              <Link to={`/product/${item.gadget.gadgetId}`} className="w-24 h-24 shrink-0 rounded-lg overflow-hidden bg-gray-50">
                <img src={item.gadget.imageUrl} alt={item.gadget.name} className="w-full h-full object-cover" />
              </Link>
              <div className="flex-1 flex flex-col">
                <Link to={`/product/${item.gadget.gadgetId}`} className="text-sm font-semibold text-ink hover:text-brand line-clamp-2">
                  {item.gadget.brand} {item.gadget.name}
                </Link>
                <span className="text-xs text-gray-500 mt-0.5">₹{Number(item.gadget.price).toLocaleString('en-IN')} each</span>
                <div className="flex items-center justify-between mt-auto">
                  <div className="flex items-center border border-gray-300 rounded-lg">
                    <button
                      onClick={() => item.quantity > 1 ? updateQuantity(item.cartItemId, item.quantity - 1) : removeFromCart(item.cartItemId)}
                      className="px-2.5 py-1 text-gray-600"
                    >−</button>
                    <span className="px-3 text-sm">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                      disabled={item.quantity >= item.gadget.stock}
                      className="px-2.5 py-1 text-gray-600 disabled:opacity-30"
                    >+</button>
                  </div>
                  <span className="font-semibold text-ink">₹{(Number(item.gadget.price) * item.quantity).toLocaleString('en-IN')}</span>
                </div>
              </div>
              <button onClick={() => removeFromCart(item.cartItemId)} className="text-gray-400 hover:text-deal self-start" aria-label="Remove">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>

        {/* Sticky order summary */}
        <div className="lg:w-80 shrink-0">
          <div className="card p-5 lg:sticky lg:top-24">
            <h2 className="font-semibold text-ink mb-4">Order Summary</h2>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Subtotal</span>
              <span>₹{subtotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Delivery</span>
              <span>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
            </div>
            {deliveryFee > 0 && (
              <p className="text-xs text-gray-400 mb-3">Add ₹{(999 - subtotal).toLocaleString('en-IN')} more for free delivery</p>
            )}
            <div className="border-t border-gray-100 pt-3 flex justify-between font-bold text-ink mb-4">
              <span>Total</span>
              <span>₹{total.toLocaleString('en-IN')}</span>
            </div>
            <button onClick={() => navigate('/checkout')} className="btn-primary w-full">Proceed to Checkout</button>
          </div>
        </div>
      </div>
    </div>
  );
}
