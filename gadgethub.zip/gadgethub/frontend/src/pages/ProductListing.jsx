import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { gadgetService } from '../services/gadgetService';
import ProductCard from '../components/ProductCard';
import SkeletonCard from '../components/SkeletonCard';
import EmptyState from '../components/EmptyState';

const CATEGORY_TYPE_MAP = {
  Mobiles: 'Mobile',
  Laptops: 'Laptop',
  Smartwatches: 'Smartwatch',
  Accessories: 'Accessory',
};

export default function ProductListing() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [allGadgets, setAllGadgets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const category = searchParams.get('category') || '';
  const search = searchParams.get('search') || '';
  const sortBy = searchParams.get('sort') || 'relevance';
  const brand = searchParams.get('brand') || '';
  const minPrice = searchParams.get('minPrice') || '';
  const maxPrice = searchParams.get('maxPrice') || '';
  const minRating = searchParams.get('minRating') || '';
  const inStockOnly = searchParams.get('inStock') === '1';

  useEffect(() => {
    setLoading(true);
    setError('');
    const fetcher = search ? gadgetService.search(search) : gadgetService.getAll();
    fetcher
      .then(setAllGadgets)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [search]);

  const brands = useMemo(() => [...new Set(allGadgets.map((g) => g.brand))].sort(), [allGadgets]);

  const filtered = useMemo(() => {
    let list = [...allGadgets];

    if (category) {
      const typeToken = CATEGORY_TYPE_MAP[category];
      list = list.filter(
        (g) =>
          g.category?.name === category ||
          (typeToken && g.gadgetType?.toLowerCase().includes(typeToken.toLowerCase()))
      );
    }
    if (brand) list = list.filter((g) => g.brand === brand);
    if (minPrice) list = list.filter((g) => Number(g.price) >= Number(minPrice));
    if (maxPrice) list = list.filter((g) => Number(g.price) <= Number(maxPrice));
    if (minRating) list = list.filter((g) => Number(g.rating || 0) >= Number(minRating));
    if (inStockOnly) list = list.filter((g) => g.stock > 0);

    if (sortBy === 'deals') {
      list = list.filter((g) => g.originalPrice && Number(g.originalPrice) > Number(g.price));
    }

    switch (sortBy) {
      case 'price_low': list.sort((a, b) => Number(a.price) - Number(b.price)); break;
      case 'price_high': list.sort((a, b) => Number(b.price) - Number(a.price)); break;
      case 'rating': list.sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0)); break;
      case 'newest': list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)); break;
      default: break;
    }
    return list;
  }, [allGadgets, category, brand, minPrice, maxPrice, minRating, inStockOnly, sortBy]);

  const updateParam = (key, value) => {
    const next = new URLSearchParams(searchParams);
    if (value === '' || value === false) next.delete(key);
    else next.set(key, value);
    setSearchParams(next);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="mb-4">
        <h1 className="text-xl font-bold text-ink">
          {search ? `Search results for "${search}"` : category ? category : 'All Gadgets'}
        </h1>
        <p className="text-sm text-gray-500">{loading ? 'Loading...' : `${filtered.length} products found`}</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar filters */}
        <aside className="lg:w-64 shrink-0">
          <div className="card p-4 sticky top-24 flex flex-col gap-5">
            <div>
              <h3 className="text-sm font-semibold text-ink mb-2">Category</h3>
              <div className="flex flex-col gap-1.5 text-sm">
                <button onClick={() => updateParam('category', '')} className={`text-left ${!category ? 'text-brand font-semibold' : 'text-gray-600'}`}>All</button>
                {Object.keys(CATEGORY_TYPE_MAP).map((c) => (
                  <button key={c} onClick={() => updateParam('category', c)} className={`text-left ${category === c ? 'text-brand font-semibold' : 'text-gray-600'}`}>{c}</button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-ink mb-2">Brand</h3>
              <select value={brand} onChange={(e) => updateParam('brand', e.target.value)} className="w-full border border-gray-300 rounded-lg text-sm px-2 py-1.5">
                <option value="">All Brands</option>
                {brands.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-ink mb-2">Price Range (₹)</h3>
              <div className="flex gap-2">
                <input type="number" placeholder="Min" value={minPrice} onChange={(e) => updateParam('minPrice', e.target.value)} className="w-1/2 border border-gray-300 rounded-lg text-sm px-2 py-1.5" />
                <input type="number" placeholder="Max" value={maxPrice} onChange={(e) => updateParam('maxPrice', e.target.value)} className="w-1/2 border border-gray-300 rounded-lg text-sm px-2 py-1.5" />
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-ink mb-2">Minimum Rating</h3>
              <div className="flex flex-col gap-1.5 text-sm">
                {[4, 3, 2].map((r) => (
                  <button key={r} onClick={() => updateParam('minRating', String(r))} className={`text-left ${minRating === String(r) ? 'text-brand font-semibold' : 'text-gray-600'}`}>
                    {r}★ & above
                  </button>
                ))}
                <button onClick={() => updateParam('minRating', '')} className="text-left text-gray-400 text-xs">Clear</button>
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm text-gray-600">
              <input type="checkbox" checked={inStockOnly} onChange={(e) => updateParam('inStock', e.target.checked ? '1' : '')} />
              In stock only
            </label>

            <button
              onClick={() => setSearchParams(search ? { search } : {})}
              className="text-xs text-brand font-semibold self-start"
            >
              Clear all filters
            </button>
          </div>
        </aside>

        {/* Main content */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-gray-500 hidden sm:inline">{filtered.length} results</span>
            <select
              value={sortBy}
              onChange={(e) => updateParam('sort', e.target.value)}
              className="border border-gray-300 rounded-lg text-sm px-3 py-2 ml-auto"
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="price_low">Price: Low to High</option>
              <option value="price_high">Price: High to Low</option>
              <option value="rating">Rating</option>
              <option value="newest">Newest</option>
            </select>
          </div>

          {error && <div className="bg-red-50 text-deal text-sm rounded-lg px-4 py-3 mb-4">{error}</div>}

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
            </div>
          ) : filtered.length === 0 ? (
            <EmptyState icon="🔍" title="No products found" description="Try adjusting your filters or search terms." />
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filtered.map((g) => <ProductCard key={g.gadgetId} gadget={g} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
