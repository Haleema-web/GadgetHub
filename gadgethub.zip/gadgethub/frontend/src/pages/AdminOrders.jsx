import { useEffect, useState } from 'react';
import { adminService } from '../services/adminService';
import { useToast } from '../context/ToastContext';
import EmptyState from '../components/EmptyState';

const STATUSES = ['PLACED', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED'];

const STATUS_STYLES = {
  PLACED: 'bg-amber-100 text-amber-700',
  CONFIRMED: 'bg-blue-100 text-blue-700',
  SHIPPED: 'bg-indigo-100 text-indigo-700',
  DELIVERED: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
};

export default function AdminOrders() {
  const { showToast } = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminService.getAllOrders().then(setOrders).finally(() => setLoading(false));
  }, []);

  const handleStatusChange = async (orderId, status) => {
    try {
      const updated = await adminService.updateOrderStatus(orderId, status);
      setOrders((prev) => prev.map((o) => (o.orderId === orderId ? updated : o)));
      showToast('Order status updated', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  if (loading) return <div className="max-w-7xl mx-auto px-4 py-10 text-gray-400">Loading orders...</div>;

  if (orders.length === 0) {
    return <EmptyState icon="🧾" title="No orders yet" description="Orders placed by customers will appear here." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold text-ink mb-6">Manage Orders</h1>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm min-w-[800px]">
          <thead className="bg-surface text-gray-500 text-xs uppercase">
            <tr>
              <th className="px-4 py-3 text-left">Order ID</th>
              <th className="px-4 py-3 text-left">Customer</th>
              <th className="px-4 py-3 text-left">Date</th>
              <th className="px-4 py-3 text-left">Amount</th>
              <th className="px-4 py-3 text-left">Payment</th>
              <th className="px-4 py-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {orders.map((order) => (
              <tr key={order.orderId}>
                <td className="px-4 py-3 font-mono text-xs">{order.orderNumber}</td>
                <td className="px-4 py-3">{order.deliveryName}</td>
                <td className="px-4 py-3 text-gray-500">{new Date(order.createdAt).toLocaleDateString()}</td>
                <td className="px-4 py-3 font-semibold">₹{Number(order.total).toLocaleString('en-IN')}</td>
                <td className="px-4 py-3 text-xs">{order.paymentMethod === 'COD' ? 'Cash on Delivery' : 'Demo Card'}</td>
                <td className="px-4 py-3">
                  <select
                    value={order.status}
                    onChange={(e) => handleStatusChange(order.orderId, e.target.value)}
                    className={`text-xs font-semibold px-2 py-1 rounded-full border-0 ${STATUS_STYLES[order.status] || 'bg-gray-100'}`}
                  >
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
