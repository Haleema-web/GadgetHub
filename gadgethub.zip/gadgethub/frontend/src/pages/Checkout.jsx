import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { orderService } from '../services/orderService';
import { useToast } from '../context/ToastContext';
import EmptyState from '../components/EmptyState';

const STEPS = ['Cart', 'Delivery Address', 'Payment', 'Confirmation'];

export default function Checkout() {
  const { cart, refreshCart } = useCart();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const items = cart.items || [];

  const [step, setStep] = useState(1); // 0-indexed into STEPS, start at "Delivery Address"
  const [address, setAddress] = useState({ deliveryName: '', deliveryPhone: '', deliveryAddress: '', deliveryCity: '', deliveryPincode: '' });
  const [paymentMethod, setPaymentMethod] = useState('COD');
  const [placing, setPlacing] = useState(false);
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');

  if (items.length === 0 && !order) {
    return (
      <EmptyState
        icon="🛒"
        title="Your cart is empty"
        description="Add some products before checking out."
        action={<Link to="/products" className="btn-primary">Browse Products</Link>}
      />
    );
  }

  const subtotal = items.reduce((sum, i) => sum + Number(i.gadget.price) * i.quantity, 0);
  const deliveryFee = subtotal >= 999 ? 0 : 49;
  const total = subtotal + deliveryFee;

  const handleAddressSubmit = (e) => {
    e.preventDefault();
    setStep(2);
  };

  const handlePlaceOrder = async () => {
    setPlacing(true);
    setError('');
    try {
      const res = await orderService.checkout({ ...address, paymentMethod });
      setOrder(res);
      await refreshCart();
      setStep(3);
      showToast('Order placed successfully!', 'success');
    } catch (err) {
      setError(err.message);
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* Step indicator */}
      <div className="flex items-center justify-between mb-8">
        {STEPS.map((label, i) => (
          <div key={label} className="flex-1 flex items-center">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
              i <= step ? 'bg-brand text-white' : 'bg-gray-200 text-gray-500'
            }`}>{i + 1}</div>
            <span className={`text-xs ml-2 hidden sm:inline ${i <= step ? 'text-ink font-medium' : 'text-gray-400'}`}>{label}</span>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 mx-2 ${i < step ? 'bg-brand' : 'bg-gray-200'}`} />}
          </div>
        ))}
      </div>

      {error && <div className="bg-red-50 text-deal text-sm rounded-lg px-4 py-3 mb-4">{error}</div>}

      {/* Step 1: Delivery Address */}
      {step === 1 && (
        <form onSubmit={handleAddressSubmit} className="card p-6 flex flex-col gap-4">
          <h2 className="font-semibold text-ink">Delivery Address</h2>
          <input required placeholder="Full Name" value={address.deliveryName}
            onChange={(e) => setAddress({ ...address, deliveryName: e.target.value })}
            className="border border-gray-300 rounded-lg px-3 py-2.5 text-sm" />
          <input required placeholder="Phone Number" value={address.deliveryPhone}
            onChange={(e) => setAddress({ ...address, deliveryPhone: e.target.value })}
            className="border border-gray-300 rounded-lg px-3 py-2.5 text-sm" />
          <textarea required placeholder="Full Address" rows={3} value={address.deliveryAddress}
            onChange={(e) => setAddress({ ...address, deliveryAddress: e.target.value })}
            className="border border-gray-300 rounded-lg px-3 py-2.5 text-sm" />
          <div className="grid grid-cols-2 gap-3">
            <input placeholder="City" value={address.deliveryCity}
              onChange={(e) => setAddress({ ...address, deliveryCity: e.target.value })}
              className="border border-gray-300 rounded-lg px-3 py-2.5 text-sm" />
            <input placeholder="Pincode" value={address.deliveryPincode}
              onChange={(e) => setAddress({ ...address, deliveryPincode: e.target.value })}
              className="border border-gray-300 rounded-lg px-3 py-2.5 text-sm" />
          </div>
          <button type="submit" className="btn-primary self-end">Continue to Payment</button>
        </form>
      )}

      {/* Step 2: Payment + Order Summary */}
      {step === 2 && (
        <div className="card p-6 flex flex-col gap-5">
          <h2 className="font-semibold text-ink">Payment Method</h2>
          <p className="text-xs text-gray-500 -mt-3">This is a demo/project payment system — no real transactions occur.</p>

          <div className="flex flex-col gap-2">
            <label className={`border rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer ${paymentMethod === 'COD' ? 'border-brand bg-brand/5' : 'border-gray-300'}`}>
              <input type="radio" checked={paymentMethod === 'COD'} onChange={() => setPaymentMethod('COD')} />
              <div>
                <div className="text-sm font-medium">Cash on Delivery</div>
                <div className="text-xs text-gray-500">Pay when your order arrives</div>
              </div>
            </label>
            <label className={`border rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer ${paymentMethod === 'DEMO_CARD' ? 'border-brand bg-brand/5' : 'border-gray-300'}`}>
              <input type="radio" checked={paymentMethod === 'DEMO_CARD'} onChange={() => setPaymentMethod('DEMO_CARD')} />
              <div>
                <div className="text-sm font-medium">Demo Card Payment</div>
                <div className="text-xs text-gray-500">Simulated card payment for demonstration only</div>
              </div>
            </label>
          </div>

          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-semibold text-ink mb-2">Order Summary</h3>
            <div className="flex flex-col gap-1 text-sm text-gray-600 mb-2">
              {items.map((i) => (
                <div key={i.cartItemId} className="flex justify-between">
                  <span>{i.gadget.name} × {i.quantity}</span>
                  <span>₹{(Number(i.gadget.price) * i.quantity).toLocaleString('en-IN')}</span>
                </div>
              ))}
            </div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Delivery</span><span>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span></div>
            <div className="flex justify-between font-bold text-ink mt-2 pt-2 border-t border-gray-100">
              <span>Total</span><span>₹{total.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div className="flex justify-between">
            <button onClick={() => setStep(1)} className="btn-secondary">Back</button>
            <button onClick={handlePlaceOrder} disabled={placing} className="btn-primary disabled:opacity-60">
              {placing ? 'Placing Order...' : 'Place Order'}
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Confirmation */}
      {step === 3 && order && (
        <div className="card p-8 text-center">
          <div className="text-5xl mb-4">✅</div>
          <h2 className="text-xl font-bold text-ink mb-1">Order placed successfully!</h2>
          <p className="text-sm text-gray-500 mb-4">Order ID: <span className="font-mono font-semibold text-ink">{order.orderNumber}</span></p>
          <p className="text-sm text-gray-600 mb-6">Total paid: <strong>₹{Number(order.total).toLocaleString('en-IN')}</strong> via {order.paymentMethod === 'COD' ? 'Cash on Delivery' : 'Demo Card Payment'}</p>
          <div className="flex justify-center gap-3">
            <Link to="/orders" className="btn-primary">View My Orders</Link>
            <Link to="/products" className="btn-secondary">Continue Shopping</Link>
          </div>
        </div>
      )}
    </div>
  );
}
