import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { adminService } from '../services/adminService';

const STAT_CARDS = [
  { key: 'totalProducts', label: 'Total Products', icon: '📦' },
  { key: 'totalUsers', label: 'Total Users', icon: '👥' },
  { key: 'totalOrders', label: 'Total Orders', icon: '🧾' },
  { key: 'totalRevenue', label: 'Total Revenue', icon: '💰', currency: true },
  { key: 'lowStock', label: 'Low Stock', icon: '⚠️' },
  { key: 'mobileProducts', label: 'Mobile Products', icon: '📱' },
  { key: 'laptopProducts', label: 'Laptop Products', icon: '💻' },
];

function BarRow({ label, value, max, color = 'bg-brand' }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div className="mb-3">
      <div className="flex justify-between text-xs text-gray-600 mb-1">
        <span>{label}</span><span className="font-semibold">{value}</span>
      </div>
      <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    adminService.getStats()
      .then(setStats)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="max-w-7xl mx-auto px-4 py-10 text-gray-400">Loading dashboard...</div>;
  if (error) return <div className="max-w-7xl mx-auto px-4 py-10 text-deal">{error}</div>;

  const byCategory = stats.productsByCategory || {};
  const byStatus = stats.ordersByStatus || {};
  const maxCategory = Math.max(1, ...Object.values(byCategory));
  const maxStatus = Math.max(1, ...Object.values(byStatus));

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <h1 className="text-xl font-bold text-ink">Admin Dashboard</h1>
        <div className="flex gap-2">
          <Link to="/admin/products" className="btn-secondary text-sm">Manage Products</Link>
          <Link to="/admin/orders" className="btn-secondary text-sm">Manage Orders</Link>
          <Link to="/admin/products/new" className="btn-primary text-sm">+ Add Gadget</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {STAT_CARDS.map((c) => (
          <div key={c.key} className="card p-4">
            <div className="text-2xl mb-1">{c.icon}</div>
            <div className="text-xl font-bold text-ink">
              {c.currency ? `₹${Number(stats[c.key] || 0).toLocaleString('en-IN')}` : stats[c.key] ?? 0}
            </div>
            <div className="text-xs text-gray-500">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card p-5">
          <h2 className="font-semibold text-ink mb-4">Products by Category</h2>
          {Object.entries(byCategory).map(([key, val]) => (
            <BarRow key={key} label={key.replace('Gadget', '')} value={val} max={maxCategory} />
          ))}
        </div>
        <div className="card p-5">
          <h2 className="font-semibold text-ink mb-4">Orders by Status</h2>
          {Object.keys(byStatus).length === 0 ? (
            <p className="text-sm text-gray-400">No orders yet.</p>
          ) : (
            Object.entries(byStatus).map(([key, val]) => (
              <BarRow key={key} label={key} value={val} max={maxStatus} color="bg-accent" />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
