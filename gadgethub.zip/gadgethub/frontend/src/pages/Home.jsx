import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { gadgetService, categoryService } from '../services/gadgetService';
import ProductCard from '../components/ProductCard';
import SkeletonCard from '../components/SkeletonCard';
import CategoryCard from '../components/CategoryCard';
import DealCountdown from '../components/DealCountdown';

const SHOP_BY_CATEGORY = [
  { name: 'Smartphones', icon: '📱', filter: 'Mobiles' },
  { name: 'Gaming Laptops', icon: '🎮', filter: 'Laptops' },
  { name: 'Student Laptops', icon: '💻', filter: 'Laptops' },
  { name: 'Smartwatches', icon: '⌚', filter: 'Smartwatches' },
  { name: 'Headphones', icon: '🎧', filter: 'Accessories' },
  { name: 'Accessories', icon: '🔌', filter: 'Accessories' },
];

function getLastViewedType() {
  return localStorage.getItem('gadgethub_last_viewed_type');
}

export default function Home() {
  const [gadgets, setGadgets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [bestsellers, setBestsellers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [all, cats, best] = await Promise.all([
          gadgetService.getAll(),
          categoryService.getAll(),
          gadgetService.getBestsellers(),
        ]);
        setGadgets(all);
        setCategories(cats);
        setBestsellers(best);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const deals = gadgets
    .filter((g) => g.originalPrice && Number(g.originalPrice) > Number(g.price))
    .sort((a, b) => (b.discountPercentage || 0) - (a.discountPercentage || 0))
    .slice(0, 8);

  const lastViewedType = getLastViewedType();
  const recommended = lastViewedType
    ? gadgets.filter((g) => g.gadgetType !== lastViewedType).slice(0, 8)
    : gadgets.slice(0, 8);

  const countFor = (name) => gadgets.filter((g) => g.category?.name === name).length;

  return (
    <div>
      {/* SECTION 1 — HERO */}
      <section className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-10 md:py-14 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <span className="inline-block text-xs font-semibold text-brand bg-brand/10 rounded-full px-3 py-1 mb-4">
              GadgetHub — BTech IT OOP Project · Group 03
            </span>
            <h1 className="text-3xl md:text-5xl font-extrabold text-ink leading-tight mb-4">
              Everything Tech.<br />All in One Place.
            </h1>
            <p className="text-gray-600 text-base md:text-lg mb-6 max-w-md">
              Discover mobiles, laptops, smart gadgets and accessories from trusted brands.
            </p>
            <div className="flex gap-3">
              <Link to="/products" className="btn-primary">Shop Now</Link>
              <Link to="/products?sort=deals" className="btn-secondary">Explore Deals</Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img src="https://placehold.co/280x280/2563EB/FFFFFF?text=Smartphone" alt="Smartphone" className="rounded-2xl w-full aspect-square object-cover" />
            <img src="https://placehold.co/280x280/111827/FFFFFF?text=Laptop" alt="Laptop" className="rounded-2xl w-full aspect-square object-cover mt-6" />
            <img src="https://placehold.co/280x280/6366F1/FFFFFF?text=Smartwatch" alt="Smartwatch" className="rounded-2xl w-full aspect-square object-cover -mt-6" />
            <img src="https://placehold.co/280x280/F5F7FA/111827?text=Headphones" alt="Headphones" className="rounded-2xl w-full aspect-square object-cover" />
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4">

        {/* SECTION 2 — QUICK CATEGORY NAVIGATION */}
        <section className="py-10">
          <h2 className="text-xl font-bold text-ink mb-4">Shop by Category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {categories.map((c) => (
              <CategoryCard key={c.categoryId} category={c} count={countFor(c.name)} />
            ))}
          </div>
        </section>

        {/* SECTION 3 — TODAY'S DEALS */}
        <section className="py-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-ink">Today's Deals</h2>
            <DealCountdown />
          </div>
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
            </div>
          ) : deals.length === 0 ? (
            <p className="text-sm text-gray-500">No active deals right now — check back soon.</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {deals.map((g) => <ProductCard key={g.gadgetId} gadget={g} />)}
            </div>
          )}
        </section>

        {/* SECTION 4 — BEST SELLERS */}
        <section className="py-6">
          <h2 className="text-xl font-bold text-ink mb-4">Best Sellers</h2>
          {loading ? (
            <div className="flex gap-4 overflow-x-auto">
              {Array.from({ length: 4 }).map((_, i) => <div key={i} className="min-w-[220px]"><SkeletonCard /></div>)}
            </div>
          ) : (
            <div className="flex gap-4 overflow-x-auto carousel-row pb-2">
              {bestsellers.map((g) => (
                <div key={g.gadgetId} className="min-w-[220px] max-w-[220px]">
                  <ProductCard gadget={g} />
                </div>
              ))}
            </div>
          )}
        </section>

        {/* SECTION 5 — SHOP BY CATEGORY (rich grid) */}
        <section className="py-6">
          <h2 className="text-xl font-bold text-ink mb-4">Explore More Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {SHOP_BY_CATEGORY.map((c) => (
              <Link
                key={c.name}
                to={`/products?category=${encodeURIComponent(c.filter)}`}
                className="card p-6 flex items-center gap-4 group"
              >
                <span className="text-4xl group-hover:scale-110 transition-transform">{c.icon}</span>
                <div>
                  <div className="font-semibold text-ink">{c.name}</div>
                  <div className="text-xs text-brand font-medium mt-1">Shop now →</div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* SECTION 6 — RECOMMENDED FOR YOU */}
        <section className="py-6">
          <h2 className="text-xl font-bold text-ink mb-1">Recommended for You</h2>
          <p className="text-xs text-gray-500 mb-4">
            {lastViewedType ? 'Based on what you recently viewed' : 'Popular picks to get you started'}
          </p>
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {recommended.map((g) => <ProductCard key={g.gadgetId} gadget={g} />)}
            </div>
          )}
        </section>

        {/* SECTION 7 — OOP PROJECT SHOWCASE */}
        <section className="py-10">
          <div className="card p-6 md:p-10 bg-ink text-white">
            <h2 className="text-2xl font-bold mb-2">Built on Real Object-Oriented Design</h2>
            <p className="text-gray-300 text-sm mb-8 max-w-2xl">
              GadgetHub's backend is structured around a genuine Java inheritance hierarchy —
              not just a UI theme. Every category-specific behaviour is driven by real method
              overriding and runtime polymorphism.
            </p>

            <div className="flex flex-col items-center mb-8">
              <div className="bg-brand text-white text-sm font-semibold rounded-lg px-4 py-2 mb-3">Gadget</div>
              <div className="w-px h-6 bg-gray-600" />
              <div className="flex flex-wrap justify-center gap-3">
                {['MobileGadget', 'LaptopGadget', 'SmartwatchGadget', 'AccessoryGadget'].map((c) => (
                  <div key={c} className="bg-white/10 border border-white/20 text-sm rounded-lg px-4 py-2">{c}</div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {[
                ['Inheritance', 'Subclasses extend the common Gadget base class'],
                ['Method Overriding', 'Each subclass redefines displayDetails()'],
                ['Runtime Polymorphism', 'The correct method runs based on the real object'],
                ['Dynamic Binding', 'Resolved by the JVM at runtime, not compile time'],
              ].map(([title, desc]) => (
                <div key={title} className="bg-white/5 rounded-lg p-4">
                  <div className="font-semibold text-sm mb-1">{title}</div>
                  <div className="text-xs text-gray-400">{desc}</div>
                </div>
              ))}
            </div>

            <Link to="/oop-concepts" className="inline-block bg-white text-ink font-semibold text-sm rounded-lg px-5 py-2.5 hover:bg-gray-100">
              See How Our OOP System Works →
            </Link>
          </div>
        </section>

        {/* SECTION 8 — TRUST / FEATURES */}
        <section className="py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              ['🔒', 'Secure Shopping', 'JWT-based authentication & hashed passwords'],
              ['📋', 'Detailed Specifications', 'Full category-specific specs for every product'],
              ['🚚', 'Fast Delivery', 'Reliable delivery estimates on every order'],
              ['↩️', 'Easy Returns', 'Hassle-free returns on eligible products'],
            ].map(([icon, title, desc]) => (
              <div key={title} className="card p-5 text-center">
                <div className="text-3xl mb-2">{icon}</div>
                <div className="font-semibold text-sm text-ink mb-1">{title}</div>
                <div className="text-xs text-gray-500">{desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 9 — FINAL CTA */}
        <section className="py-14 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-ink mb-4">Find Your Next Gadget</h2>
          <Link to="/products" className="btn-primary inline-block">Explore All Gadgets</Link>
        </section>
      </div>
    </div>
  );
}
