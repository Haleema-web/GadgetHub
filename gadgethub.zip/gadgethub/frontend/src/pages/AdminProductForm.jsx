import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { gadgetService, categoryService } from '../services/gadgetService';
import { useToast } from '../context/ToastContext';

const EMPTY_FORM = {
  gadgetType: 'MOBILE',
  name: '', brand: '', model: '', price: '', originalPrice: '', stock: '', warranty: '',
  description: '', imageUrl: '', categoryId: '',
  cameraMP: '', batteryCapacity: '', screenSize: '', operatingSystem: '', storage: '',
  processor: '', ram: '', graphicsCard: '',
  displayType: '', batteryLife: '', waterResistance: '', compatibleOS: '',
  accessoryType: '', compatibility: '',
};

export default function AdminProductForm() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [form, setForm] = useState(EMPTY_FORM);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    categoryService.getAll().then(setCategories).catch(() => {});
    if (isEdit) {
      gadgetService.getById(id).then((g) => {
        const type = g.gadgetType.replace('Gadget', '').toUpperCase();
        setForm({
          ...EMPTY_FORM,
          gadgetType: type,
          name: g.name || '', brand: g.brand || '', model: g.model || '',
          price: g.price || '', originalPrice: g.originalPrice || '', stock: g.stock ?? '',
          warranty: g.warranty || '', description: g.description || '', imageUrl: g.imageUrl || '',
          categoryId: g.category?.categoryId || '',
          cameraMP: g.cameraMP ?? '', batteryCapacity: g.batteryCapacity ?? '',
          screenSize: g.screenSize ?? '', operatingSystem: g.operatingSystem || '', storage: g.storage ?? '',
          processor: g.processor || '', ram: g.ram ?? '', graphicsCard: g.graphicsCard || '',
          displayType: g.displayType || '', batteryLife: g.batteryLife || '',
          waterResistance: g.waterResistance || '', compatibleOS: g.compatibleOS || '',
          accessoryType: g.accessoryType || '', compatibility: g.compatibility || '',
        });
      }).finally(() => setLoading(false));
    }
  }, [id, isEdit]);

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const payload = {
        ...form,
        price: Number(form.price),
        originalPrice: form.originalPrice ? Number(form.originalPrice) : null,
        stock: Number(form.stock),
        categoryId: form.categoryId ? Number(form.categoryId) : null,
        cameraMP: form.cameraMP ? Number(form.cameraMP) : null,
        batteryCapacity: form.batteryCapacity ? Number(form.batteryCapacity) : null,
        screenSize: form.screenSize ? Number(form.screenSize) : null,
        storage: form.storage ? Number(form.storage) : null,
        ram: form.ram ? Number(form.ram) : null,
      };
      if (isEdit) {
        await gadgetService.update(id, payload);
        showToast('Product updated', 'success');
      } else {
        await gadgetService.create(payload);
        showToast('Product created', 'success');
      }
      navigate('/admin/products');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="max-w-3xl mx-auto px-4 py-10 text-gray-400">Loading...</div>;

  const inputCls = 'w-full border border-gray-300 rounded-lg px-3 py-2 text-sm';
  const labelCls = 'text-xs font-medium text-gray-600 block mb-1';

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-xl font-bold text-ink mb-6">{isEdit ? 'Edit Gadget' : 'Add New Gadget'}</h1>

      {error && <div className="bg-red-50 text-deal text-sm rounded-lg px-4 py-3 mb-4">{error}</div>}

      <form onSubmit={handleSubmit} className="card p-6 flex flex-col gap-5">
        <div>
          <label className={labelCls}>Category Type</label>
          <select value={form.gadgetType} onChange={(e) => update('gadgetType', e.target.value)}
            disabled={isEdit} className={`${inputCls} disabled:bg-gray-100`}>
            <option value="MOBILE">Mobile</option>
            <option value="LAPTOP">Laptop</option>
            <option value="SMARTWATCH">Smartwatch</option>
            <option value="ACCESSORY">Accessory</option>
          </select>
          {isEdit && <p className="text-xs text-gray-400 mt-1">Category type cannot be changed after creation.</p>}
        </div>

        {/* Common fields */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div><label className={labelCls}>Name</label><input required value={form.name} onChange={(e) => update('name', e.target.value)} className={inputCls} /></div>
          <div><label className={labelCls}>Brand</label><input required value={form.brand} onChange={(e) => update('brand', e.target.value)} className={inputCls} /></div>
          <div><label className={labelCls}>Model</label><input value={form.model} onChange={(e) => update('model', e.target.value)} className={inputCls} /></div>
          <div>
            <label className={labelCls}>Category</label>
            <select value={form.categoryId} onChange={(e) => update('categoryId', e.target.value)} className={inputCls}>
              <option value="">Select category</option>
              {categories.map((c) => <option key={c.categoryId} value={c.categoryId}>{c.name}</option>)}
            </select>
          </div>
          <div><label className={labelCls}>Price (₹)</label><input required type="number" min="0" value={form.price} onChange={(e) => update('price', e.target.value)} className={inputCls} /></div>
          <div><label className={labelCls}>Original Price (₹)</label><input type="number" min="0" value={form.originalPrice} onChange={(e) => update('originalPrice', e.target.value)} className={inputCls} /></div>
          <div><label className={labelCls}>Stock</label><input required type="number" min="0" value={form.stock} onChange={(e) => update('stock', e.target.value)} className={inputCls} /></div>
          <div><label className={labelCls}>Warranty</label><input value={form.warranty} onChange={(e) => update('warranty', e.target.value)} className={inputCls} placeholder="1 Year Manufacturer Warranty" /></div>
        </div>

        <div><label className={labelCls}>Image URL</label><input value={form.imageUrl} onChange={(e) => update('imageUrl', e.target.value)} className={inputCls} placeholder="https://placehold.co/500x500" /></div>
        <div><label className={labelCls}>Description</label><textarea rows={3} value={form.description} onChange={(e) => update('description', e.target.value)} className={inputCls} /></div>

        {/* Dynamic fields based on gadgetType */}
        {form.gadgetType === 'MOBILE' && (
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-semibold text-ink mb-3">Mobile Specifications</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className={labelCls}>Camera (MP)</label><input type="number" value={form.cameraMP} onChange={(e) => update('cameraMP', e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Battery (mAh)</label><input type="number" value={form.batteryCapacity} onChange={(e) => update('batteryCapacity', e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Screen Size (inches)</label><input type="number" step="0.1" value={form.screenSize} onChange={(e) => update('screenSize', e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>OS</label><input value={form.operatingSystem} onChange={(e) => update('operatingSystem', e.target.value)} className={inputCls} placeholder="Android 14" /></div>
              <div><label className={labelCls}>Storage (GB)</label><input type="number" value={form.storage} onChange={(e) => update('storage', e.target.value)} className={inputCls} /></div>
            </div>
          </div>
        )}

        {form.gadgetType === 'LAPTOP' && (
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-semibold text-ink mb-3">Laptop Specifications</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className={labelCls}>Processor</label><input value={form.processor} onChange={(e) => update('processor', e.target.value)} className={inputCls} placeholder="Intel Core i5-1235U" /></div>
              <div><label className={labelCls}>RAM (GB)</label><input type="number" value={form.ram} onChange={(e) => update('ram', e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Storage (GB)</label><input type="number" value={form.storage} onChange={(e) => update('storage', e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>Graphics Card</label><input value={form.graphicsCard} onChange={(e) => update('graphicsCard', e.target.value)} className={inputCls} /></div>
              <div><label className={labelCls}>OS</label><input value={form.operatingSystem} onChange={(e) => update('operatingSystem', e.target.value)} className={inputCls} placeholder="Windows 11" /></div>
              <div><label className={labelCls}>Screen Size (inches)</label><input type="number" step="0.1" value={form.screenSize} onChange={(e) => update('screenSize', e.target.value)} className={inputCls} /></div>
            </div>
          </div>
        )}

        {form.gadgetType === 'SMARTWATCH' && (
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-semibold text-ink mb-3">Smartwatch Specifications</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className={labelCls}>Display Type</label><input value={form.displayType} onChange={(e) => update('displayType', e.target.value)} className={inputCls} placeholder="AMOLED" /></div>
              <div><label className={labelCls}>Battery Life</label><input value={form.batteryLife} onChange={(e) => update('batteryLife', e.target.value)} className={inputCls} placeholder="7 days" /></div>
              <div><label className={labelCls}>Water Resistance</label><input value={form.waterResistance} onChange={(e) => update('waterResistance', e.target.value)} className={inputCls} placeholder="5 ATM" /></div>
              <div><label className={labelCls}>Compatible OS</label><input value={form.compatibleOS} onChange={(e) => update('compatibleOS', e.target.value)} className={inputCls} placeholder="Android & iOS" /></div>
            </div>
          </div>
        )}

        {form.gadgetType === 'ACCESSORY' && (
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-semibold text-ink mb-3">Accessory Specifications</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><label className={labelCls}>Accessory Type</label><input value={form.accessoryType} onChange={(e) => update('accessoryType', e.target.value)} className={inputCls} placeholder="Headphones" /></div>
              <div><label className={labelCls}>Compatibility</label><input value={form.compatibility} onChange={(e) => update('compatibility', e.target.value)} className={inputCls} placeholder="Universal Bluetooth" /></div>
            </div>
          </div>
        )}

        <div className="flex justify-end gap-3 border-t border-gray-100 pt-5">
          <button type="button" onClick={() => navigate('/admin/products')} className="btn-secondary">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary disabled:opacity-60">
            {saving ? 'Saving...' : isEdit ? 'Save Changes' : 'Create Gadget'}
          </button>
        </div>
      </form>
    </div>
  );
}
