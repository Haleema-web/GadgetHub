import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { gadgetService } from '../services/gadgetService';
import ProductCard from '../components/ProductCard';
import EmptyState from '../components/EmptyState';

function getWishlistIds() {
  try { return JSON.parse(localStorage.getItem('gadgethub_wishlist') || '[]'); }
  catch { return []; }
}

export default function Wishlist() {
  const [gadgets, setGadgets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const ids = getWishlistIds();
    if (ids.length === 0) {
      setLoading(false);
      return;
    }
    Promise.all(ids.map((id) => gadgetService.getById(id).catch(() => null)))
      .then((results) => setGadgets(results.filter(Boolean)))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="max-w-7xl mx-auto px-4 py-10 text-gray-400">Loading wishlist...</div>;

  if (gadgets.length === 0) {
    return (
      <EmptyState
        icon="💙"
        title="Your wishlist is empty"
        description="Tap the heart icon on any product to save it here."
        action={<Link to="/products" className="btn-primary">Browse Products</Link>}
      />
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-xl font-bold text-ink mb-6">My Wishlist ({gadgets.length})</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {gadgets.map((g) => <ProductCard key={g.gadgetId} gadget={g} />)}
      </div>
    </div>
  );
}
